
import pylibxc
import pytest
from pylibxc.example_densities import test_data


def test_lda_x_rel_N_2_zk():
    # Prepare the input
    inp = test_data["N"]

    # Get the functional
    feval = pylibxc.LibXCFunctional("lda_x_rel", 2)
    if not feval._have_exc:
        pytest.skip("build lacks the derivative order for zk")

    # Evaluate only up to the tested field's derivative order. Computing higher
    # orders than this test checks is wasteful and can trip a latent bug in an
    # order the test does not exercise (e.g. an fxc segfault under a vrho test).
    out = feval.compute(inp, do_exc=feval._have_exc, do_vxc=False, do_fxc=False, do_kxc=False, do_lxc=False)
    ns = pylibxc.array_backend.array_namespace(out["zk"])
    tgt = out["zk"].flatten()
    ref_tgt = ns.full_like(tgt, ns.asarray([-4.118489125994057e+00, -4.037023583020146e+00, -3.922677700797559e+00, -3.763915136601145e+00, -3.546916823616689e+00, -3.256968158185817e+00, -2.881986827210678e+00, -2.419278965514951e+00, -1.886015378982010e+00, -1.333540667189409e+00, -8.741945110627173e-01, -6.699771601548385e-01, -5.892331220806584e-01, -4.717652886152321e-01, -3.231485435271834e-01, -1.841352850335473e-01, -8.361429603297599e-02, -2.795281088931593e-02, -5.998601344674072e-03, -6.741774111168624e-04]))
    error = ns.max(ns.abs(tgt-ref_tgt))/(1.0+ns.max(ns.asarray([ns.abs(tgt), ns.abs(ref_tgt)])))
    assert error < 5e-08


def test_lda_x_rel_N_2_vrho():
    # Prepare the input
    inp = test_data["N"]

    # Get the functional
    feval = pylibxc.LibXCFunctional("lda_x_rel", 2)
    if not feval._have_vxc:
        pytest.skip("build lacks the derivative order for vrho")

    # Evaluate only up to the tested field's derivative order. Computing higher
    # orders than this test checks is wasteful and can trip a latent bug in an
    # order the test does not exercise (e.g. an fxc segfault under a vrho test).
    out = feval.compute(inp, do_exc=feval._have_exc, do_vxc=feval._have_vxc, do_fxc=False, do_kxc=False, do_lxc=False)
    ns = pylibxc.array_backend.array_namespace(out["vrho"])
    tgt = out["vrho"].flatten()
    ref_tgt = ns.full_like(tgt, ns.asarray([-5.461952767025645e+00, -5.461909866846067e+00, -5.355079480875959e+00, -5.354989605821825e+00, -5.204970677899973e+00, -5.204781362304685e+00, -4.996371090464084e+00, -4.995969158653407e+00, -4.710945914484839e+00, -4.710082776821270e+00, -4.329103109308788e+00, -4.327218281545512e+00, -3.834752316331485e+00, -3.830533017686568e+00, -3.224678924799964e+00, -3.214874188619332e+00, -2.523768770057985e+00, -2.499669396080316e+00, -1.807271346617666e+00, -1.743408579820786e+00, -1.232435564899170e+00, -1.059633942629615e+00, -9.670250614608813e-01, -6.518809450133393e-01, -8.497462345055712e-01, -5.549714827666338e-01, -6.807455384439525e-01, -4.517656189592886e-01, -4.657686308466574e-01, -2.995368536767210e-01, -2.640299607579688e-01, -1.563906596318280e-01, -1.182882012463062e-01, -6.040816089661346e-02, -3.866128633164824e-02, -1.544180151661800e-02, -8.115968713415125e-03, -2.216961719204873e-03, -9.021359633051974e-04, -1.466713895379297e-04]))
    error = ns.max(ns.abs(tgt-ref_tgt))/(1.0+ns.max(ns.asarray([ns.abs(tgt), ns.abs(ref_tgt)])))
    assert error < 5e-05


def test_lda_x_rel_N_2_v2rho2():
    # Prepare the input
    inp = test_data["N"]

    # Get the functional
    feval = pylibxc.LibXCFunctional("lda_x_rel", 2)
    if not feval._have_fxc:
        pytest.skip("build lacks the derivative order for v2rho2")

    # Evaluate only up to the tested field's derivative order. Computing higher
    # orders than this test checks is wasteful and can trip a latent bug in an
    # order the test does not exercise (e.g. an fxc segfault under a vrho test).
    out = feval.compute(inp, do_exc=feval._have_exc, do_vxc=feval._have_vxc, do_fxc=feval._have_fxc, do_kxc=False, do_lxc=False)
    ns = pylibxc.array_backend.array_namespace(out["v2rho2"])
    tgt = out["v2rho2"].flatten()
    ref_tgt = ns.full_like(tgt, ns.asarray([-1.968018227590851e-02, -7.044203657368268e-133, -1.968051728269873e-02, -2.053991505405686e-02, -1.761050914342067e-133, -2.054065979728092e-02, -2.183811645855270e-02, -1.408840731473654e-132, -2.183982504490337e-02, -2.384025632094478e-02, 1.761050914342067e-133, -2.384435795477963e-02, -2.702279377027229e-02, -7.044203657368268e-133, -2.703330447660236e-02, -3.230473910812184e-02, -7.044203657368268e-133, -3.233433029618975e-02, -4.162556331197662e-02, -3.522101828684134e-133, -4.172097211165577e-02, -5.955376271118559e-02, -4.226522194420961e-132, -5.992773321294687e-02, -9.827955673450836e-02, 4.226522194420961e-132, -1.002160244789010e-01, -1.932382272736917e-01, 1.408840731473654e-132, -2.077791242686556e-01, -4.174605821816954e-01, -1.690608877768384e-131, -5.653084352504114e-01, -6.791041567968302e-01, -1.127072585178923e-131, -1.496436726134256e+00, -8.799883795676405e-01, -9.016580681431383e-131, -2.065319163557145e+00, -1.372086160317083e+00, -6.762435511073537e-131, -3.117602911342083e+00, -2.932864575607144e+00, 1.127072585178923e-130, -7.093771408490364e+00, -9.130491059182571e+00, 2.704974204429415e-130, -2.602738800476884e+01, -4.549684681294774e+01, 1.442652909029021e-129, -1.744555258975437e+02, -4.259178266664233e+02, 0.000000000000000e+00, -2.669831907475440e+03, -9.664943497413386e+03, 0.000000000000000e+00, -1.295280206846616e+05, -7.822329931465711e+05, -1.181821263076574e-124, -2.959302152893489e+07]))
    error = ns.max(ns.abs(tgt-ref_tgt))/(1.0+ns.max(ns.asarray([ns.abs(tgt), ns.abs(ref_tgt)])))
    assert error < 5e-05
