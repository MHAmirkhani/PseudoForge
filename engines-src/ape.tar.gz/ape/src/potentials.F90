!! Copyright (C) 2004-2014 M. Oliveira, F. Nogueira
!! Copyright (C) 2014 P. Borlido
!!
!! This program is free software; you can redistribute it and/or modify
!! it under the terms of the GNU General Public License as published by
!! the Free Software Foundation; either version 2, or (at your option)
!! any later version.
!!
!! This program is distributed in the hope that it will be useful,
!! but WITHOUT ANY WARRANTY; without even the implied warranty of
!! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
!! GNU General Public License for more details.
!!
!! You should have received a copy of the GNU General Public License
!! along with this program; if not, write to the Free Software
!! Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
!! 02110-1301, USA.
!!

#include "global.h"

module potentials_m
  use global_m
  use messages_m
  use mesh_m
  use mixing_m
  use quantum_numbers_m
  use loc_potentials_m
  use sl_potentials_m
  use kb_projectors_m
  use hf_potentials_m
  implicit none


                    !---Interfaces---!

  interface assignment (=)
     module procedure potential_copy
  end interface

  interface potential_init
     module procedure potential_init_ae, potential_init_ps, &
                      potential_init_ps_scr, potential_init_ps_full, &
                      potential_init_kb, potential_init_hf
   end interface


                    !---Derived Data Types---!

  type potential_t
    private
    integer      :: type
    type(mesh_t) :: m

    type(loc_potential_t), pointer :: vl
    type(sl_potential_t),  pointer :: vsl
    type(kb_projectors_t), pointer :: kb
    type(hf_potential_t),  pointer :: vhf

    !Screening  will be treated as a local potential
    logical :: screened
    logical :: polarized
    integer :: nspin
    type(loc_potential_t), pointer :: vhxc(:)
    type(loc_potential_t), pointer :: vxctau(:)
  end type potential_t


                    !---Global Variables---!

  integer, parameter :: LOC = 1, &
                        SL  = 2, &
                        KBP = 3, &
                        HF  = 4

                    !---Public/Private Statements---!

  private
  public :: potential_t, &
            potential_null, &
            potential_init, &
            assignment(=), &
            potential_end, &
            potential_save, &
            potential_load, &
            classical_turning_point, &
            n, &
            v, &
            dvdr, &
            d2vdr2, &
            bxc, &
            vtau, &
            dvtaudr, &
            bxc_integral, &
            potential_debug, &
            potential_update_vhxc, &
            potential_update_vhf, &
            potential_mix, &
            potential_nuclear_charge, &
            potential_is_polarized, &
            potential_min, &
            potential_max, &
            potential_rmin, &
            potential_rmax, &
            potential_kb_energy, &
            potential_output, &
            potential_ps_io_set, &
            potential_init_hf

contains

  !-----------------------------------------------------------------------
  !> Nullifies and sets to zero all the components of the potential.      
  !-----------------------------------------------------------------------
  subroutine potential_null(potential)
    type(potential_t), intent(out) :: potential


    potential%type = 0
    call mesh_null(potential%m)

    nullify(potential%vl)
    nullify(potential%vsl)
    nullify(potential%kb)
    nullify(potential%vhf)

    potential%screened = .false.
    potential%polarized = .false.
    potential%nspin = 0
    nullify(potential%vhxc)
    nullify(potential%vxctau)

  end subroutine potential_null

  !-----------------------------------------------------------------------
  !> Initialize the potential for averaged HF calculations
  !-----------------------------------------------------------------------
  subroutine potential_init_hf(potential, m, nc, qn, v, n, z)
    type(potential_t), intent(inout) :: potential
    type(mesh_t),      intent(in)    :: m
    integer,           intent(in)    :: nc
    type(qn_t),        intent(in)    :: qn(nc)
    real(R8),          intent(in)    :: v(m%np, nc)
    real(R8),          intent(in)    :: n(m%np, nc)
    real(R8),          intent(in)    :: z


    ASSERT(potential%type == 0)

    potential%type = HF
    potential%m = m

    allocate(potential%vl)
    call loc_potential_null(potential%vl)
    call loc_potential_init(potential%vl, m, z=z)

    allocate(potential%vhf)
    call hf_potential_null(potential%vhf)
    call hf_potential_init(potential%vhf, m, nc, qn, v, n)

    potential%screened = .false.

  end subroutine potential_init_hf

  !-----------------------------------------------------------------------
  !> Initialize the potential.                                            
  !-----------------------------------------------------------------------
  subroutine potential_init_ae(potential, m, nspin, vhxc, vxctau, z)
    type(potential_t), intent(inout) :: potential           !< potential to be initialized
    type(mesh_t),      intent(in)    :: m                   !< mesh
    integer,           intent(in)    :: nspin               !< number of spin channels
    real(R8),          intent(in)    :: vhxc(m%np, nspin)   !< Hartree and exchange-correlation potential
    real(R8),          intent(in)    :: vxctau(m%np, nspin) !< extra exchange-correlation term from MGGA
    real(R8),          intent(in)    :: z                   !< nuclear charge


    ASSERT(potential%type == 0)

    potential%type = LOC
    potential%m = m

    allocate(potential%vl)
    call loc_potential_null(potential%vl)
    call loc_potential_init(potential%vl, m, z=z)

    potential%screened = .true.
    call potential_init_vhxc(potential, nspin, vhxc, vxctau)

  end subroutine potential_init_ae

  !-----------------------------------------------------------------------
  !> Initialize a single pseudo-potential without screening.              
  !-----------------------------------------------------------------------
  subroutine potential_init_ps(potential, m, v)
    type(potential_t), intent(inout) :: potential !< potential to be initialized
    type(mesh_t),      intent(in)    :: m         !< mesh
    real(R8),          intent(in)    :: v(m%np)   !< values of the potential on the mesh


    ASSERT(potential%type == 0)

    potential%type = LOC
    potential%m = m

    allocate(potential%vl)
    call loc_potential_null(potential%vl)
    call loc_potential_init(potential%vl, m, v=v)

    potential%screened = .false.

  end subroutine potential_init_ps

  !-----------------------------------------------------------------------
  !> Initialize a single pseudo-potential with screening.                 
  !-----------------------------------------------------------------------
  subroutine potential_init_ps_scr(potential, m, nspin, vhxc, vxctau, v)
    type(potential_t), intent(inout) :: potential           !< potential to be initialized
    type(mesh_t),      intent(in)    :: m                   !< mesh
    integer,           intent(in)    :: nspin               !< number of spin channels
    real(R8),          intent(in)    :: vhxc(m%np, nspin)   !< Hartree and exchange-correlation potential
    real(R8),          intent(in)    :: vxctau(m%np, nspin) !< extra exchange-correlation term from MGGA
    real(R8),          intent(in)    :: v(m%np)             !< values of the potential on the mesh


    ASSERT(potential%type == 0)

    potential%type = LOC
    potential%m = m

    allocate(potential%vl)
    call loc_potential_null(potential%vl)
    call loc_potential_init(potential%vl, m, v=v)

    potential%screened = .true.
    call potential_init_vhxc(potential, nspin, vhxc, vxctau)

  end subroutine potential_init_ps_scr

  !-----------------------------------------------------------------------
  !> Initialize a full set of pseudo-potentials with screening.           
  !-----------------------------------------------------------------------
  subroutine potential_init_ps_full(potential, m, nspin, vhxc, vxctau, nc, qn, v)
    type(potential_t), intent(inout) :: potential           !< potential to be initialized
    type(mesh_t),      intent(in)    :: m                   !< mesh
    integer,           intent(in)    :: nspin               !< number of spin channels
    real(R8),          intent(in)    :: vhxc(m%np, nspin)   !< Hartree and exchange-correlation potential
    real(R8),          intent(in)    :: vxctau(m%np, nspin) !< extra exchange-correlation term from MGGA
    integer,           intent(in)    :: nc                  !< number of components
    type(qn_t),        intent(in)    :: qn(nc)              !< quantum numbers of each component
    real(R8),          intent(in)    :: v(m%np, nc)         !< values of the potentials on the mesh for each component


    ASSERT(potential%type == 0)

    potential%type = SL
    potential%m = m

    allocate(potential%vsl)
    call sl_potential_null(potential%vsl)
    call sl_potential_init(potential%vsl, m, nc, qn, v)

    potential%screened = .true.
    call potential_init_vhxc(potential, nspin, vhxc, vxctau)

  end subroutine potential_init_ps_full

  !-----------------------------------------------------------------------
  !> Initialize a full set of pseudo-potentials with screening.           
  !-----------------------------------------------------------------------
  subroutine potential_init_kb(potential, m, l_local, v_local, nc, qn, e, proj_f)
    type(potential_t), intent(inout) :: potential        !< potential to be initialized
    type(mesh_t),      intent(in)    :: m                !< mesh
    integer,           intent(in)    :: l_local          !< local potential angular momentum
    type(potential_t), intent(in)    :: v_local          !< the local part of the potential
    integer,           intent(in)    :: nc               !< the number of KB projectors
    type(qn_t),        intent(in)    :: qn(nc)           !< quantum numbers of each component
    real(R8),          intent(in)    :: e(nc)            !< the KB energies
    real(R8),          intent(in)    :: proj_f(m%np, nc) !< values of the projectors on the mesh

    integer :: is


    ASSERT(potential%type == 0)
    ASSERT(v_local%type == LOC)

    potential%type = KBP
    potential%m = m

    allocate(potential%kb)
    call kb_projectors_null(potential%kb)
    call kb_projectors_init(potential%kb, l_local, v_local%vl, m, nc, qn, e, proj_f)

    potential%screened = v_local%screened
    if (v_local%screened) then
      potential%nspin = v_local%nspin
      allocate(potential%vhxc(potential%nspin), potential%vxctau(potential%nspin))
      do is = 1, potential%nspin
        call loc_potential_null(potential%vhxc(is))
        call loc_potential_null(potential%vxctau(is))
        potential%vhxc(is) = v_local%vhxc(is)
        potential%vxctau(is) = v_local%vxctau(is)
      end do
    end if

  end subroutine potential_init_kb
  
  !-----------------------------------------------------------------------
  !> Initialize the Hartree and exchange-correlation part of the potential
  !-----------------------------------------------------------------------
  subroutine potential_init_vhxc(potential, nspin, vhxc, vxctau)
    type(potential_t), intent(inout) :: potential                     !< potential to be initialized
    integer,           intent(in)    :: nspin                         !< number of spin channels
    real(R8),          intent(in)    :: vhxc(potential%m%np, nspin)   !< Hartree and exchange-correlation potential
    real(R8),          intent(in)    :: vxctau(potential%m%np, nspin) !< extra exchange-correlation term from MGGA

    integer :: is
    real(R8) :: ra, rb, bxc_int


    ASSERT(potential%type /= 0)

    potential%nspin = nspin
    allocate(potential%vhxc(nspin), potential%vxctau(nspin))
    do is = 1, nspin
      call loc_potential_null(potential%vhxc(is))
      call loc_potential_null(potential%vxctau(is))
      call loc_potential_init(potential%vhxc(is), potential%m, v=vhxc(:, is))
      call loc_potential_init(potential%vxctau(is), potential%m, v=vxctau(:, is))
    end do

    if (nspin == 2) then
      ra = potential_rmin(potential)
      rb = potential_rmax(potential)
      bxc_int = M_HALF*(loc_integral(potential%vhxc(2), ra, rb) - &
                        loc_integral(potential%vhxc(1), ra, rb))
      potential%polarized = abs(bxc_int) > 1e-10
    else
      potential%polarized = .false.
    end if

  end subroutine potential_init_vhxc

  !-----------------------------------------------------------------------
  !> Copies the potential potential_a to potential potential_b.           
  !-----------------------------------------------------------------------
  subroutine potential_copy(potential_a, potential_b)
    type(potential_t), intent(inout) :: potential_a
    type(potential_t), intent(in)    :: potential_b

    integer :: is


    ASSERT(potential_b%type /= 0)

    call potential_end(potential_a)

    potential_a%type = potential_b%type
    potential_a%m = potential_b%m

    select case (potential_b%type)
    case (LOC)
      allocate(potential_a%vl)
      call loc_potential_null(potential_a%vl)
      potential_a%vl = potential_b%vl
    case (SL)
      allocate(potential_a%vsl)
      call sl_potential_null(potential_a%vsl)
      potential_a%vsl = potential_b%vsl
    case (KBP)
      allocate(potential_a%kb)
      call kb_projectors_null(potential_a%kb)
      potential_a%kb = potential_b%kb
    case(HF)
      allocate(potential_a%vl)
      call loc_potential_null(potential_a%vl)
      potential_a%vl = potential_b%vl

      allocate(potential_a%vhf)
      call hf_potential_null(potential_a%vhf)
      potential_a%vhf = potential_b%vhf
    end select

    potential_a%screened = potential_b%screened
    potential_a%polarized = potential_b%polarized
    potential_a%nspin = potential_b%nspin
    if (potential_b%screened) then
      allocate(potential_a%vhxc(potential_a%nspin), potential_a%vxctau(potential_a%nspin))
      do is = 1, potential_a%nspin
        call loc_potential_null(potential_a%vhxc(is))
        call loc_potential_null(potential_a%vxctau(is))
        potential_a%vhxc(is) = potential_b%vhxc(is)
        potential_a%vxctau(is) = potential_b%vxctau(is)
      end do
    end if

  end subroutine potential_copy

  !-----------------------------------------------------------------------
  !> Frees all the memory associated to the potential.                    
  !-----------------------------------------------------------------------
  subroutine potential_end(potential)
    type(potential_t), intent(inout) :: potential

    integer :: is


    potential%type = 0
    call mesh_end(potential%m)

    if (associated(potential%vl)) then
      call loc_potential_end(potential%vl)
      deallocate(potential%vl)
    end if

    if (associated(potential%vsl)) then
      call sl_potential_end(potential%vsl)
      deallocate(potential%vsl)
    end if

    if (associated(potential%vhf)) then
      call hf_potential_end(potential%vhf)
      deallocate(potential%vhf)
    end if

    if (associated(potential%kb)) then
      call kb_projectors_end(potential%kb)
      deallocate(potential%kb)
    end if

    if (associated(potential%vhxc)) then
      do is = 1, potential%nspin
        call loc_potential_end(potential%vhxc(is))
        call loc_potential_end(potential%vxctau(is))
      end do
      deallocate(potential%vhxc, potential%vxctau)
    end if
    potential%nspin = 0
    potential%screened = .false.

  end subroutine potential_end

  !-----------------------------------------------------------------------
  !> Writes the potential to a file.                                      
  !-----------------------------------------------------------------------
  subroutine potential_save(unit, potential)
    integer,           intent(in) :: unit      !< file unit number
    type(potential_t), intent(in) :: potential !< potential to be written

    integer :: is


    ASSERT(potential%type /= 0)

    write(unit) potential%type
    call mesh_save(unit, potential%m)

    select case (potential%type)
    case (LOC)
      call loc_potential_save(unit, potential%m, potential%vl)
    case (SL)
      call sl_potential_save(unit, potential%m, potential%vsl)
    case (KBP)
      call kb_projectors_save(unit, potential%m, potential%kb)
    case (HF)
      call loc_potential_save(unit, potential%m, potential%vl)
      call hf_potential_save(unit, potential%m, potential%vhf)
    end select

    write(unit) potential%screened
    if (potential%screened) then
      write(unit) potential%nspin
      do is = 1, potential%nspin
        call loc_potential_save(unit, potential%m, potential%vhxc(is))
        call loc_potential_save(unit, potential%m, potential%vxctau(is))
      end do
    end if

  end subroutine potential_save

  !-----------------------------------------------------------------------
  !> Reads the potential from a file.                                     
  !-----------------------------------------------------------------------
  subroutine potential_load(unit, potential)
    integer,           intent(in)    :: unit      !< file unit number
    type(potential_t), intent(inout) :: potential !< potential to be read

    integer :: is


    ASSERT(potential%type == 0)

    read(unit) potential%type
    call mesh_load(unit, potential%m)

    select case (potential%type)
    case (LOC)
      allocate(potential%vl)
      call loc_potential_null(potential%vl)
      call loc_potential_load(unit, potential%m, potential%vl)
    case (SL)
      allocate(potential%vsl)
      call sl_potential_null(potential%vsl)
      call sl_potential_load(unit, potential%m, potential%vsl)
    case (KBP)
      allocate(potential%kb)
      call kb_projectors_null(potential%kb)
      call kb_projectors_load(unit, potential%m, potential%kb)
    case (HF)
      allocate(potential%vhf)
      allocate(potential%vl)
      call loc_potential_null(potential%vl)
      call loc_potential_load(unit, potential%m, potential%vl)
      call hf_potential_null(potential%vhf)
      call hf_potential_load(unit, potential%m, potential%vhf)
    end select

    read(unit) potential%screened
    if (potential%screened) then
      read(unit) potential%nspin
      allocate(potential%vhxc(potential%nspin), potential%vxctau(potential%nspin))
      do is = 1, potential%nspin
        call loc_potential_null(potential%vhxc(is))
        call loc_potential_null(potential%vxctau(is))
        call loc_potential_load(unit, potential%m, potential%vhxc(is))
        call loc_potential_load(unit, potential%m, potential%vxctau(is))
      end do
    end if

  end subroutine potential_load

  !-----------------------------------------------------------------------
  !> Returns the closest mesh point to the point at which the potential is
  !> equal to a given energy.                                             
  !-----------------------------------------------------------------------
  function classical_turning_point(potential, e, qn)
    type(potential_t), intent(in) :: potential !< potential
    real(R8),          intent(in) :: e         !< energy
    type(qn_t),        intent(in) :: qn        !< set of quantum numbers
    real(R8) :: classical_turning_point

    integer  :: i
    real(R8) :: d


    ASSERT(potential%type /= 0)

    if (e == M_ZERO) then
      classical_turning_point = potential%m%r(potential%m%np - 1)
    else
      d = v(potential, potential%m%r(potential%m%np), qn) - e
      do i = potential%m%np - 1, 1, -1
        if ((v(potential, potential%m%r(i), qn) - e)*d <= M_ZERO) then
          classical_turning_point = potential%m%r(i)
          exit
        end if
      end do
      if (i == 1) then
        if (d > M_ZERO) then
          classical_turning_point = potential%m%r(2)
        else
          classical_turning_point = potential%m%r(potential%m%np - 1)
        end if
      end if
    end if

  end function classical_turning_point

  !-----------------------------------------------------------------------
  !> Returns the value of the potential felt by an electron of at radius r
  !-----------------------------------------------------------------------
  function v(potential, r, qn, unscreened)
    type(potential_t), intent(in) :: potential
    real(R8),          intent(in) :: r
    type(qn_t),        intent(in) :: qn
    logical,           intent(in), optional :: unscreened
    real(R8) :: v

    logical :: unscreened_

    ASSERT(potential%type /= 0)

    if( r <= potential%m%r(potential%m%np)) then
      select case (potential%type)
      case (LOC)
        v = loc_v(potential%vl, r)
      case (SL)
        v = sl_v(potential%vsl, r, qn)
      case (KBP)
        v = kb_v(potential%kb, r)
      case (HF)
        v = loc_v(potential%vl, r)
      end select

      if (potential%screened) then
        unscreened_ = .false.
        if (present(unscreened)) unscreened_ = unscreened
        if (.not. unscreened_) then          
          if (potential%type == HF) v = v + hf_v(potential%vhf, r, qn)

          if (qn%s == M_ZERO .and. qn%m /= M_ZERO) then
            v = v + M_HALF*(loc_v(potential%vhxc(1), r) + loc_v(potential%vhxc(2), r))
          else
            v = v + loc_v(potential%vhxc(int(qn%s + 1.5_r8)), r)
          end if
        end if
      end if

    else
      v = M_ZERO
    end if

  end function v

  !-----------------------------------------------------------------------
  !> Returns the value of the non homogeneous term of the HF equations
  !> for the set of qn qn at point r
  !-----------------------------------------------------------------------
  function n(potential, r, qn)
    type(potential_t), intent(in) :: potential
    real(R8),          intent(in) :: r
    type(qn_t),        intent(in) :: qn
    real(R8) :: n

    ASSERT(potential%type /= 0)

    if( r <= potential%m%r(potential%m%np) .and. potential%type == HF) then
      n = hf_n(potential%vhf, r, qn)
    else
      n = M_ZERO
    end if

  end function n

  !-----------------------------------------------------------------------
  !> Returns the value of the first derivative of the potential felt by an
  !> electron at radius r.                                                
  !-----------------------------------------------------------------------
  function dvdr(potential, r, qn)
    type(potential_t), intent(in) :: potential
    real(R8),          intent(in) :: r
    type(qn_t),        intent(in) :: qn
    real(R8) :: dvdr

    ASSERT(potential%type /= 0)

    if( r <= potential%m%r(potential%m%np)) then
      select case (potential%type)
      case (LOC)
        dvdr = loc_dvdr(potential%vl, r)
      case (SL)
        dvdr = sl_dvdr(potential%vsl, r, qn)
      case (KBP)
        dvdr = kb_dvdr(potential%kb, r)
      case (HF)
        dvdr = loc_dvdr(potential%vl, r) + hf_dvdr(potential%vhf, r, qn)
      end select

      if (potential%screened) then
        if (qn%s == M_ZERO .and. qn%m /= M_ZERO) then
          dvdr = dvdr + M_HALF*(loc_dvdr(potential%vhxc(1), r) + loc_dvdr(potential%vhxc(2), r))
        else
          dvdr = dvdr + loc_dvdr(potential%vhxc(int(qn%s + 1.5_r8)), r)
        end if
      end if

    else
      dvdr = M_ZERO
    end if

  end function dvdr

  !-----------------------------------------------------------------------
  !> Returns the value of the second derivative of the potential felt by  
  !> an electron at radius r.                                             
  !-----------------------------------------------------------------------
  function d2vdr2(potential, r, qn)
    type(potential_t), intent(in) :: potential
    real(R8),          intent(in) :: r
    type(qn_t),        intent(in) :: qn
    real(R8) :: d2vdr2

    ASSERT(potential%type /= 0)

    if( r <= potential%m%r(potential%m%np)) then
      select case (potential%type)
      case (LOC)
        d2vdr2 = loc_d2vdr2(potential%vl, r)
      case (SL)
        d2vdr2 = sl_d2vdr2(potential%vsl, r, qn)
      case (KBP)
        d2vdr2 = kb_d2vdr2(potential%kb, r)
      case (HF)
        d2vdr2 = loc_d2vdr2(potential%vl, r) + hf_d2vdr2(potential%vhf, r, qn)
      end select

      if (potential%screened) then
        if (qn%s == M_ZERO .and. qn%m /= M_ZERO) then
          d2vdr2 = d2vdr2 + M_HALF*(loc_d2vdr2(potential%vhxc(1), r) + loc_d2vdr2(potential%vhxc(2), r))
        else
          d2vdr2 = d2vdr2 + loc_d2vdr2(potential%vhxc(int(qn%s + 1.5_r8)), r)
        end if
      end if

    else
      d2vdr2 = M_ZERO
    end if

  end function d2vdr2

  !-----------------------------------------------------------------------
  !> Returns the value of the potential felt by an electron of at radius r
  !-----------------------------------------------------------------------
  function bxc(potential, r)
    type(potential_t), intent(in) :: potential
    real(R8),          intent(in) :: r
    real(R8) :: bxc

    ASSERT(potential%type /= 0)
    ASSERT(potential%screened)

    if(potential%nspin == 2 .and. r <= potential%m%r(potential%m%np)) then
      bxc = M_HALF*(loc_v(potential%vhxc(2), r) - loc_v(potential%vhxc(1), r))
    else
      bxc = M_ZERO
    end if

  end function bxc

  !-----------------------------------------------------------------------
  !> Returns the value of the extra exchange-correlation term from MGGA   
  !> at radius r.                                                         
  !-----------------------------------------------------------------------
  function vtau(potential, r, qn)
    type(potential_t), intent(in) :: potential
    real(R8),          intent(in) :: r
    type(qn_t),        intent(in) :: qn
    real(R8) :: vtau

    ASSERT(potential%type /= 0)

    if( r <= potential%m%r(potential%m%np) .and. potential%screened) then
      vtau = loc_v(potential%vxctau(int(qn%s + 1.5_r8)), r)
    else
      vtau = M_ZERO
    end if

  end function vtau

  !-----------------------------------------------------------------------
  !> Returns the value of the first derivative of the extra               
  !> exchange-correlation term from MGGA at radius r.                     
  !-----------------------------------------------------------------------
  function dvtaudr(potential, r, qn)
    type(potential_t), intent(in) :: potential
    real(R8),          intent(in) :: r
    type(qn_t),        intent(in) :: qn
    real(R8) :: dvtaudr

    ASSERT(potential%type /= 0)

    if( r <= potential%m%r(potential%m%np) .and. potential%screened) then
      dvtaudr = loc_dvdr(potential%vxctau(int(qn%s + 1.5_r8)), r)
    else
      dvtaudr = M_ZERO
    end if

  end function dvtaudr

  !-----------------------------------------------------------------------
  !> Returns the value of the integral of bxc between ra and rb.          
  !-----------------------------------------------------------------------
  function bxc_integral(potential, ra, rb)
    type(potential_t),  intent(in) :: potential
    real(R8), optional, intent(in) :: ra, rb
    real(R8) :: bxc_integral

    real(R8) :: ra_, rb_

    ASSERT(potential%type /= 0)
    ASSERT(potential%screened)

    if (present(ra)) then
      ra_ = ra
      ra_ = max(potential_rmin(potential), ra_)
      ra_ = min(potential_rmax(potential), ra_)
    else
      ra_ = potential_rmin(potential)
    end if

    if (present(rb)) then
      rb_ = rb
      rb_ = max(potential_rmin(potential), rb_)
      rb_ = min(potential_rmax(potential), rb_)
    else
      rb_ = potential_rmax(potential)
    end if

    if (potential%nspin == 2) then
      bxc_integral = M_HALF*(loc_integral(potential%vhxc(2), ra_, rb_) - &
                             loc_integral(potential%vhxc(1), ra_, rb_))
    else
      bxc_integral = M_ZERO
    end if

  end function bxc_integral

  !-----------------------------------------------------------------------
  !> Prints debug information to the "debug_info" directory.              
  !-----------------------------------------------------------------------
  subroutine potential_debug(potential)
    type(potential_t), intent(in) :: potential


    ASSERT(potential%type /= 0)

    call potential_output(potential, "debug_info")

  end subroutine potential_debug

  !-----------------------------------------------------------------------
  !> Update the value of the Hartree and exchange-correlation part of the 
  !> potential.                                                           
  !-----------------------------------------------------------------------
  subroutine potential_update_vhxc(potential, vhxc, vxctau)
    type(potential_t), intent(inout) :: potential
    real(R8),          intent(in)    :: vhxc(:,:)
    real(R8),          intent(in)    :: vxctau(:,:)

    integer :: is


    ASSERT(potential%type /= 0 .and. potential%screened)

    do is = 1, potential%nspin
      call loc_potential_end(potential%vhxc(is))
      call loc_potential_end(potential%vxctau(is))
    end do
    deallocate(potential%vhxc, potential%vxctau)

    call potential_init_vhxc(potential, potential%nspin, vhxc, vxctau)

  end subroutine potential_update_vhxc

  !-----------------------------------------------------------------------
  !> Update potential for Hartree-Fock case
  !-----------------------------------------------------------------------
  subroutine potential_update_vhf(potential, m, nc, v, n)
    type(potential_t),    intent(inout) :: potential
    integer,              intent(in)    :: nc
    type(mesh_t),         intent(in)    :: m
    real(R8),             intent(in)    :: v(m%np, nc)
    real(R8),             intent(in)    :: n(m%np, nc)


    ASSERT(potential%type /= 0)

    call hf_potential_update(potential%vhf, m, nc, v, n)

  end subroutine potential_update_vhf

  !-----------------------------------------------------------------------
  !> Mix input and output all-electron potentials. This subroutine should 
  !> be used during an self-consistent field cycle and is only valid for  
  !> all-electron potentials. On exit the input potential.                
  !> is replaced by the mixed potential.                                  
  !-----------------------------------------------------------------------
  subroutine potential_mix(pot_in, pot_out, nit, mix)
    type(potential_t), intent(inout) :: pot_in  !< input potential/new potential
    type(potential_t), intent(in)    :: pot_out !< output potential
    integer,           intent(in)    :: nit     !< number of iteration of the SCF cycle
    type(mixing_t),    intent(inout) :: mix     !< information about the mixing procedure

    integer  :: is, i, np, nspin
    integer  :: nc
    real(R8), allocatable :: vhxc_in(:), vhxc_out(:), vhxc_new(:), vhxc(:,:), vxctau(:,:)
    real(R8), allocatable :: v_in(:), v_out(:), v_new(:), vhf(:,:), nhf(:,:) 


    ASSERT(pot_in%type == pot_out%type)

    select case (pot_in%type)
    case (LOC, SL, KBP)
      !Default case for all electron calculations
      ASSERT(pot_in%screened .and. pot_out%screened)

      np = pot_in%m%np
      nspin = pot_in%nspin

      !Put all the components of vhxc in a single vector
      allocate(vhxc_in(np*pot_in%nspin*2))
      allocate(vhxc_out(np*pot_in%nspin*2))
      allocate(vhxc_new(np*pot_in%nspin*2))
      do is = 1, pot_in%nspin
        do i = 1, np
          vhxc_in(np*(is - 1) + i)  = loc_v(pot_in%vhxc(is),  pot_in%m%r(i))
          vhxc_out(np*(is - 1) + i) = loc_v(pot_out%vhxc(is), pot_in%m%r(i))
          vhxc_in(np*(is + nspin - 1) + i)  = loc_v(pot_in%vxctau(is),  pot_in%m%r(i))
          vhxc_out(np*(is + nspin - 1) + i) = loc_v(pot_out%vxctau(is), pot_in%m%r(i))
        end do
      end do

      !Mix
      call mixing(mix, nit, vhxc_in, vhxc_out, vhxc_new)

      !Put the components of vhxc_new back to the original ordering
      allocate(vhxc(np, pot_in%nspin), vxctau(np, pot_in%nspin))
      do is = 1, pot_in%nspin
        do i = 1, np
          vhxc(i, is) = vhxc_new(np*(is - 1) + i)
          vxctau(i, is) = vhxc_new(np*(is + nspin - 1) + i)
        end do
      end do

      !Replace vhxc part of the input potential by the new vhxc
      call potential_update_vhxc(pot_in, vhxc, vxctau)
      deallocate(vhxc_in, vhxc_out, vhxc_new, vhxc, vxctau)

    case(HF)
      !HF potential has screened=False so it will give assertion error.
      !Check later to incorporate in previous scheme

      np = pot_in%m%np
      nc = pot_in%vhf%nc
     
      !Put all the components of the potential in a single vector
      allocate(v_in(2*np*nc))
      allocate(v_out(2*np*nc))
      allocate(v_new(2*np*nc))
      do is = 1, nc
        do i = 1, np
          v_in(np*(is-1) + i)  = hf_v(pot_in%vhf,  pot_in%m%r(i),  pot_in%vhf%qn(is))        
          v_out(np*(is-1) + i) = hf_v(pot_out%vhf, pot_out%m%r(i), pot_out%vhf%qn(is))
          v_in(np*(nc+is-1) + i)  = hf_n(pot_in%vhf,  pot_in%m%r(i),  pot_in%vhf%qn(is))
          v_out(np*(nc+is-1) + i) = hf_n(pot_out%vhf, pot_out%m%r(i), pot_out%vhf%qn(is))
        end do
      end do
      
      !Mix potential
      call mixing(mix, nit, v_in, v_out, v_new)

      !Put the components back in original order
      allocate(vhf(np, nc), nhf(np, nc))
      do is = 1, nc
        do i = 1, np
          vhf(i, is) = v_new(np*(is - 1) + i)
          nhf(i, is) = v_new(np*(nc + is - 1) + i)
        end do
      end do

      !Udate the potential
      call potential_update_vhf(pot_in, pot_in%m, nc, vhf, nhf)

      !Deallocate arrays
      deallocate(v_in, v_out, v_new)
      deallocate(vhf, nhf)

    end select

  end subroutine potential_mix

  !-----------------------------------------------------------------------
  !> Returns the value of the nuclear charge of an all-electron potential.
  !> Returns zero for other types of potentials.                          
  !-----------------------------------------------------------------------
  function potential_nuclear_charge(potential)
    type(potential_t), intent(in) :: potential
    real(R8) :: potential_nuclear_charge


    ASSERT(potential%type /= 0)

    select case (potential%type)
    case (LOC, HF)
      potential_nuclear_charge = loc_potential_nuclear_charge(potential%vl)
    case default
      potential_nuclear_charge = M_ZERO
    end select

  end function potential_nuclear_charge

  !-----------------------------------------------------------------------
  !>
  !-----------------------------------------------------------------------
  function potential_is_polarized(potential)
    type(potential_t), intent(in) :: potential
    logical :: potential_is_polarized


    ASSERT(potential%type /= 0)

    potential_is_polarized = potential%polarized

  end function potential_is_polarized

  !-----------------------------------------------------------------------
  !> Returns the minimum value of the potential.                          
  !-----------------------------------------------------------------------
  function potential_min(potential, qn)
    type(potential_t), intent(in) :: potential
    type(qn_t),        intent(in) :: qn
    real(R8) :: potential_min
 
    integer :: i
    real(R8) :: vv
 

    ASSERT(potential%type /= 0)

    if (potential%type == LOC .or. potential%type == HF) then
      if (loc_potential_is_ae(potential%vl)) then
        message(1) = "Trying to find the minimun of an all-electron potential."
        call write_fatal(1)
      end if
    end if

    potential_min = M_ZERO
    do i = 1, potential%m%np
      vv = v(potential, potential%m%r(i), qn)
      if (vv < potential_min) potential_min = vv
    end do

  end function potential_min

  !-----------------------------------------------------------------------
  !> Returns the maximum value of the potential.                          
  !-----------------------------------------------------------------------
  function potential_max(potential, qn)
    type(potential_t), intent(in) :: potential
    type(qn_t),        intent(in) :: qn
    real(R8) :: potential_max
 
    integer :: i
    real(R8) :: vv
 

    ASSERT(potential%type /= 0)

    potential_max = v(potential, potential%m%r(1), qn)
    do i = 2, potential%m%np
      vv = v(potential, potential%m%r(i), qn)
      if (vv > potential_max) potential_max = vv
    end do

  end function potential_max

  !-----------------------------------------------------------------------
  !> Closest point to the origin that can be safely used.                 
  !-----------------------------------------------------------------------
  function potential_rmin(potential)
    type(potential_t), intent(in) :: potential
    real(R8) :: potential_rmin


    ASSERT(potential%type /= 0)

    potential_rmin = potential%m%r(1)

  end function potential_rmin

  !-----------------------------------------------------------------------
  !> Larger point that can be safely used.                                
  !-----------------------------------------------------------------------
  function potential_rmax(potential)
    type(potential_t), intent(in) :: potential
    real(R8) :: potential_rmax


    ASSERT(potential%type /= 0)

    potential_rmax = potential%m%r(potential%m%np)

  end function potential_rmax

  !-----------------------------------------------------------------------
  !> Returns the value of the KB energy.                                  
  !-----------------------------------------------------------------------
  function potential_kb_energy(potential, qn)
    type(potential_t), intent(in) :: potential
    type(qn_t),        intent(in) :: qn
    real(R8) :: potential_kb_energy


    ASSERT(potential%type == KBP)

    potential_kb_energy = kb_projectors_energy(potential%kb, qn)

  end function potential_kb_energy

  !-----------------------------------------------------------------------
  !> Writes the potential to a file in a format suitable for plotting.    
  !-----------------------------------------------------------------------
  subroutine potential_output(potential, dir)
    type(potential_t), intent(in) :: potential
    character(len=*),     intent(in) :: dir


    ASSERT(potential%type /= 0)

    select case (potential%type)
    case (LOC)
      call loc_potential_output(potential%vl, potential%m, trim(dir)//"/v_ext")
    case (SL)
      call sl_potential_output(potential%vsl, potential%m, dir)
    case (KBP)
      call kb_projectors_output(potential%kb, potential%m, dir)
    case (HF)
      call loc_potential_output(potential%vl, potential%m, trim(dir)//"/v_ext")
      call hf_potential_output(potential%vhf, potential%m, dir)
    end select

    if (potential%screened) then
      if (potential%nspin == 1) then
        call loc_potential_output(potential%vhxc(1), potential%m, trim(dir)//"/v_hxc")
      else
        call loc_potential_output(potential%vhxc(1), potential%m, trim(dir)//"/v_hxc_dn")
        call loc_potential_output(potential%vhxc(2), potential%m, trim(dir)//"/v_hxc_up")
      end if
    end if

  end subroutine potential_output

  !-----------------------------------------------------------------------
  !> Pass the information about the pseudopotentials to the ps_io module. 
  !-----------------------------------------------------------------------
  subroutine potential_ps_io_set(potential)
    type(potential_t), intent(in) :: potential


    ASSERT(potential%type == SL .or. potential%type == KBP)

    select case (potential%type)
    case (SL)
      call sl_potential_ps_io_set(potential%vsl, potential%m)
    case (KBP)
      call kb_projectors_ps_io_set(potential%kb, potential%m)
    end select

  end subroutine potential_ps_io_set

end module potentials_m
