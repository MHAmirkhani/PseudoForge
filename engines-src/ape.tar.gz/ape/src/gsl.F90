!! Copyright (C) 2026 M. Oliveira
!!
!! This program is free software; you can redistribute it and/or modify
!! it under the terms of the GNU General Public License as published by
!! the Free Software Foundation; either version 2, or (at your option)
!! any later version.
!!
!! This program is distributed in the hope that it will be useful,
!! but WITHOUT ANY WARRANTY; without even the implied warranty of
!! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
!! GNU General Public License for more details.
!!
!! You should have received a copy of the GNU General Public License
!! along with this program; if not, write to the Free Software
!! Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
!! 02110-1301, USA.
!!

module gsl_m
  use, intrinsic :: iso_c_binding
  use global_m
  use utilities_m
  implicit none

  private
  public :: &
    gsl_strerror, &
    gsl_sf_coupling_3j, &
    gsl_vector_t, &
    gsl_vector_alloc, &
    gsl_vector_free, &
    gsl_vector_set, &
    gsl_vector_get, &
    gsl_matrix_t, &
    gsl_matrix_alloc, &
    gsl_matrix_calloc, &
    gsl_matrix_free, &
    gsl_matrix_set, &
    gsl_matrix_get, &
    gsl_permutation_t, &
    gsl_permutation_alloc, &
    gsl_permutation_free, &
    gsl_linalg_lu_decomp, &
    gsl_linalg_lu_invert, &
    gsl_linalg_lu_solve, &
    gsl_odeiv_step_t, &
    gsl_odeiv_step_alloc, &
    gsl_odeiv_step_free, &
    gsl_odeiv_evolve_t, &
    gsl_odeiv_evolve_alloc, &
    gsl_odeiv_evolve_reset, &
    gsl_odeiv_evolve_free, &
    gsl_odeiv_control_t, &
    gsl_odeiv_control_standard_new, &
    gsl_odeiv_control_free, &
    gsl_spline_t, &
    gsl_interp_accel_t, &
    gsl_spline_init, &
    gsl_spline_alloc, &
    gsl_spline_free, &
    gsl_interp_accel_alloc, &
    gsl_interp_accel_free, &
    gsl_spline_eval, &
    gsl_spline_eval_deriv, &
    gsl_spline_eval_deriv2, &
    gsl_spline_eval_integ, &
    gsl_multiroot_fsolver_t, &
    gsl_multiroot_fsolver_alloc, &
    gsl_multiroot_fsolver_free

  ! Interfaces to C functions that can be called directly
  interface
    function gsl_sf_coupling_3j(ja, jb, jc, ma, mb, mc) bind(c)
      !Computes the value of (ja/2 jb/2 jc/2),
      !                      (ma/2 mb/2 mc/2)
      import
      integer(c_int) , intent(in) :: ja, jb, jc, ma, mb, mc
      real(c_double) :: gsl_sf_coupling_3j
    end function gsl_sf_coupling_3j
  end interface

  ! Types
  type :: gsl_vector_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_vector_t

  type :: gsl_matrix_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_matrix_t

  type :: gsl_permutation_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_permutation_t

  type :: gsl_odeiv_step_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_odeiv_step_t

  type :: gsl_odeiv_step_type_t
    type(c_ptr) :: ptr
  end type gsl_odeiv_step_type_t

  type :: gsl_odeiv_evolve_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_odeiv_evolve_t

  type :: gsl_odeiv_control_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_odeiv_control_t

  type :: gsl_spline_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_spline_t

  type :: gsl_interp_accel_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_interp_accel_t

  type :: gsl_multiroot_fsolver_t
    type(c_ptr) :: ptr = C_NULL_PTR
  end type gsl_multiroot_fsolver_t

contains

  ! Error Handling

  function gsl_strerror(errno)
    !Returns a string describing the error code
    integer(c_int), intent(in) :: errno
    character(kind=c_char,len=128) :: gsl_strerror
    interface
      type(c_ptr) function gsl_strerror_c(errno) bind(c, name="gsl_strerror")
        import
        integer(c_int), value :: errno
      end function gsl_strerror_c
    end interface

    type(c_ptr) :: str

    str = gsl_strerror_c(errno)
    call c_to_f_string_ptr(str, gsl_strerror)

  end function gsl_strerror

  ! Vectors and Matrices

  subroutine gsl_vector_alloc(n, v)
    !Creates a vector of length n, returning a pointer
    !to a newly initialized vector struct
    integer, intent(in) :: n
    type(gsl_vector_t), intent(out) :: v
    interface
      type(c_ptr) function gsl_vector_alloc_c(n) bind(c, name="gsl_vector_alloc")
        import
        integer(c_int), value :: n
      end function gsl_vector_alloc_c
    end interface

    v%ptr = gsl_vector_alloc_c(n)

  end subroutine gsl_vector_alloc

  subroutine gsl_vector_free(v)
    !Frees a previously allocated vector v
    type(gsl_vector_t), intent(inout) :: v
    interface
      subroutine gsl_vector_free_c(v) bind(c, name="gsl_vector_free")
        import
        type(c_ptr), value :: v
      end subroutine gsl_vector_free_c
    end interface

    call gsl_vector_free_c(v%ptr)

  end subroutine gsl_vector_free

  subroutine gsl_vector_set(v, i, x)
    !Sets the value of the i-th element of a vector v to x
    integer, intent(in) :: i
    real(R8), intent(in) :: x
    type(gsl_vector_t), intent(inout) :: v
    interface
      subroutine gsl_vector_set_c(v, i, x) bind(c, name="gsl_vector_set")
        import
        integer, value :: i
        real(c_double), value :: x
        type(c_ptr), value :: v
      end subroutine gsl_vector_set_c
    end interface

    call gsl_vector_set_c(v%ptr, i, x)

  end subroutine gsl_vector_set

  real(R8) function gsl_vector_get(v, i)
    !Returns the i-th element of a vector v
    integer, intent(in) :: i
    type(gsl_vector_t), intent(in) :: v
    interface
      real(c_double) function gsl_vector_get_c(v, i) bind(c, name="gsl_vector_get")
        import
        integer, value :: i
        type(c_ptr), value :: v
      end function gsl_vector_get_c
    end interface

    gsl_vector_get = gsl_vector_get_c(v%ptr, i)

  end function gsl_vector_get

  subroutine gsl_matrix_alloc(n1, n2, m)
    !Creates a matrix of size n1 rows by n2 columns, returning
    !a pointer to a newly initialized matrix struct
    integer, intent(in) :: n1, n2
    type(gsl_matrix_t), intent(out) :: m
    interface
      type(c_ptr) function gsl_matrix_alloc_c(n1, n2) bind(c, name="gsl_matrix_alloc")
        import
        integer(c_int), value :: n1, n2
      end function gsl_matrix_alloc_c
    end interface

    m%ptr = gsl_matrix_alloc_c(n1, n2)

  end subroutine gsl_matrix_alloc

  subroutine gsl_matrix_calloc(n1, n2, m)
    !Allocates memory for a matrix of size n1 rows by n2 columns
    !and initializes all the elements of the matrix to zero
    integer, intent(in) :: n1, n2
    type(gsl_matrix_t), intent(out) :: m
    interface
      type(c_ptr) function gsl_matrix_calloc_c(n1, n2) bind(c, name="gsl_matrix_calloc")
        import
        integer(c_int), value :: n1, n2
      end function gsl_matrix_calloc_c
    end interface

    m%ptr = gsl_matrix_calloc_c(n1, n2)

  end subroutine gsl_matrix_calloc

  subroutine gsl_matrix_free(m)
    !Frees a previously allocated matrix m
    type(gsl_matrix_t), intent(inout) :: m
    interface
      subroutine gsl_matrix_free_c(m) bind(c, name="gsl_matrix_free")
        import
        type(c_ptr), value :: m
      end subroutine gsl_matrix_free_c
    end interface

    call gsl_matrix_free_c(m%ptr)

  end subroutine gsl_matrix_free

  subroutine gsl_matrix_set(m, i, j, x)
    !Sets the value of the (i,j)th element of a matrix m to x
    integer, intent(in) :: i, j
    real(R8), intent(in) :: x
    type(gsl_matrix_t), intent(inout) :: m
    interface
      subroutine gsl_matrix_set_c(m, i, j, x) bind(c, name="gsl_matrix_set")
        import
        integer, value :: i, j
        real(c_double), value :: x
        type(c_ptr), value :: m
      end subroutine gsl_matrix_set_c
    end interface

    call gsl_matrix_set_c(m%ptr, i, j, x)

  end subroutine gsl_matrix_set

  real(R8) function gsl_matrix_get(m, i, j)
    !Returns the (i,j)th element of a matrix m
    integer, intent(in) :: i, j
    type(gsl_matrix_t), intent(in) :: m
    interface
      real(c_double) function gsl_matrix_get_c(m, i, j) bind(c, name="gsl_matrix_get")
        import
        integer, value :: i, j
        type(c_ptr), value :: m
      end function gsl_matrix_get_c
    end interface

    gsl_matrix_get = gsl_matrix_get_c(m%ptr, i, j)

  end function gsl_matrix_get

  ! Permutations

  subroutine gsl_permutation_alloc(n, p)
    !Allocates memory for a new permutation of size n
    integer, intent(in) :: n
    type(gsl_permutation_t), intent(out) :: p
    interface
      type(c_ptr) function gsl_permutation_alloc_c(n) bind(c, name="gsl_permutation_alloc")
        import
        integer(c_int), value :: n
      end function gsl_permutation_alloc_c
    end interface

    p%ptr = gsl_permutation_alloc_c(n)

  end subroutine gsl_permutation_alloc

  subroutine gsl_permutation_free(p)
    !Frees all the memory used by the permutation p
    type(gsl_permutation_t), intent(inout) :: p
    interface
      subroutine gsl_permutation_free_c(p) bind(c, name="gsl_permutation_free")
        import
        type(c_ptr), value :: p
      end subroutine gsl_permutation_free_c
    end interface

    call gsl_permutation_free_c(p%ptr)

  end subroutine gsl_permutation_free

  ! Linear Algebra

  integer function gsl_linalg_lu_decomp(m, p, signum)
    !Factorizes the square matrix A into the LU decomposition PA = LU
    type(gsl_matrix_t), intent(inout) :: m
    type(gsl_permutation_t), intent(inout) :: p
    integer, intent(out) :: signum
    interface
      integer(c_int) function gsl_linalg_lu_decomp_c(m, p, signum) bind(c, name="gsl_linalg_LU_decomp")
        import
        type(c_ptr), value :: m, p
        integer(c_int) :: signum
      end function gsl_linalg_lu_decomp_c
    end interface

    gsl_linalg_lu_decomp = gsl_linalg_lu_decomp_c(m%ptr, p%ptr, signum)

  end function gsl_linalg_lu_decomp

  integer function gsl_linalg_lu_invert(lu, p, inverse)
    !Computes the inverse of a matrix A from its LU decomposition (LU,p)
    type(gsl_matrix_t), intent(in) :: lu
    type(gsl_permutation_t), intent(in) :: p
    type(gsl_matrix_t), intent(inout) :: inverse
    interface
      integer(c_int) function gsl_linalg_lu_invert_c(lu, p, inverse) bind(c, name="gsl_linalg_LU_invert")
        import
        type(c_ptr), value :: lu, p, inverse
      end function gsl_linalg_lu_invert_c
    end interface

    gsl_linalg_lu_invert = gsl_linalg_lu_invert_c(lu%ptr, p%ptr, inverse%ptr)

  end function gsl_linalg_lu_invert

  integer function gsl_linalg_lu_solve(a, p, b, x)
    !Solves the system A x = b using the LU decomposition of A into (LU, p)
    type(gsl_matrix_t), intent(inout) :: a
    type(gsl_permutation_t), intent(inout) :: p
    type(gsl_vector_t), intent(in) :: b
    type(gsl_vector_t), intent(inout) :: x
    interface
      integer(c_int) function gsl_linalg_lu_solve_c(a, p, b, x) bind(c, name="gsl_linalg_LU_solve")
        import
        type(c_ptr), value :: a, p, b, x
      end function gsl_linalg_lu_solve_c
    end interface

    gsl_linalg_lu_solve = gsl_linalg_lu_solve_c(a%ptr, p%ptr, b%ptr, x%ptr)

  end function gsl_linalg_lu_solve

  ! Ordinary Differential Equations

  subroutine gsl_odeiv_step_alloc(stepping_func, dim, stp)
    !Returns a pointer to a newly allocated instance of a stepping function
    integer, intent(in) :: stepping_func, dim
    type(gsl_odeiv_step_t), intent(out) :: stp
    interface
      type(c_ptr) function gsl_odeiv_step_type_new(type) bind(c)
        import
        integer(c_int), value :: type
      end function gsl_odeiv_step_type_new

      type(c_ptr) function gsl_odeiv_step_alloc_c(type, dim) bind(c, name="gsl_odeiv_step_alloc")
        import
        type(c_ptr), value :: type
        integer(c_int), value :: dim
      end function gsl_odeiv_step_alloc_c
    end interface

    stp%ptr = gsl_odeiv_step_alloc_c(gsl_odeiv_step_type_new(stepping_func), dim)

  end subroutine gsl_odeiv_step_alloc

  subroutine gsl_odeiv_step_free(stp)
    !Frees all the memory associated with the stepping function stp
    type(gsl_odeiv_step_t), value :: stp
    interface
      subroutine gsl_odeiv_step_free_c(stp) bind(c, name="gsl_odeiv_step_free")
        import
        type(c_ptr), value :: stp
      end subroutine gsl_odeiv_step_free_c
    end interface

    call gsl_odeiv_step_free_c(stp%ptr)

  end subroutine gsl_odeiv_step_free

  subroutine gsl_odeiv_evolve_alloc(dim, evl)
    !Returns a pointer to a newly allocated instance of an evolution function
    integer, intent(in) :: dim
    type(gsl_odeiv_evolve_t), intent(inout) :: evl
    interface
      type(c_ptr) function gsl_odeiv_evolve_alloc_c(dim) bind(c, name="gsl_odeiv_evolve_alloc")
        import
        integer(c_int), value :: dim
      end function gsl_odeiv_evolve_alloc_c
    end interface

    evl%ptr = gsl_odeiv_evolve_alloc_c(dim)

  end subroutine gsl_odeiv_evolve_alloc

  integer function gsl_odeiv_evolve_reset(evl)
    !Resets the evolution function evl
    type(gsl_odeiv_evolve_t), intent(inout) :: evl
    interface
      integer(c_int) function gsl_odeiv_evolve_reset_c(evl) bind(c, name="gsl_odeiv_evolve_reset")
        import
        type(c_ptr), value :: evl
      end function gsl_odeiv_evolve_reset_c
    end interface

    gsl_odeiv_evolve_reset = gsl_odeiv_evolve_reset_c(evl%ptr)

  end function gsl_odeiv_evolve_reset

  subroutine gsl_odeiv_evolve_free(evl)
    !Frees all the memory associated with the evolution function evl
    type(gsl_odeiv_evolve_t), intent(inout) :: evl
    interface
      subroutine gsl_odeiv_evolve_free_c(evl) bind(c, name="gsl_odeiv_evolve_free")
        import
        type(c_ptr), value :: evl
      end subroutine gsl_odeiv_evolve_free_c
    end interface

    call gsl_odeiv_evolve_free_c(evl%ptr)

  end subroutine gsl_odeiv_evolve_free

  subroutine gsl_odeiv_control_standard_new(ctrl, eps_abs, eps_rel, a_y, a_dydt)
    !Creates a new control function. The standard control object is a four
    !parameter heuristic based on absolute and relative errors eps_abs and
    !eps_rel, and scaling factors a_y and a_dydt for the system state y(t)
    !and derivatives dydt(t) respectively
    type(gsl_odeiv_control_t), intent(inout) :: ctrl
    real(R8), intent(in) :: eps_abs, eps_rel, a_y, a_dydt
    interface
      type(c_ptr) function gsl_odeiv_control_standard_new_c(eps_abs, eps_rel, a_y, a_dydt) &
        bind(c, name="gsl_odeiv_control_standard_new")
        import
        real(c_double), value :: eps_abs, eps_rel, a_y, a_dydt
      end function gsl_odeiv_control_standard_new_c
    end interface

    ctrl%ptr = gsl_odeiv_control_standard_new_c(eps_abs, eps_rel, a_y, a_dydt)

  end subroutine gsl_odeiv_control_standard_new

  subroutine gsl_odeiv_control_free(ctrl)
    !Frees all the memory associated with the control function ctrl
    type(gsl_odeiv_control_t), intent(inout) :: ctrl
    interface
      subroutine gsl_odeiv_control_free_c(ctrl) bind(c, name="gsl_odeiv_control_free")
        import
        type(c_ptr), value :: ctrl
      end subroutine gsl_odeiv_control_free_c
    end interface

    call gsl_odeiv_control_free_c(ctrl%ptr)

  end subroutine gsl_odeiv_control_free

  ! Interpolation

  integer function gsl_spline_init(spl, x, f, n)
    !Initializes the interpolation object spl for the data (x,f)
    type(gsl_spline_t), intent(inout) :: spl
    real(R8), intent(in), target, contiguous :: x(:), f(:)
    integer, intent(in) :: n
    interface
      integer(c_int) function gsl_spline_init_c(spl, x, f, n) bind(c, name="gsl_spline_init")
        import
        integer(c_size_t), value :: n
        type(c_ptr), value :: x, f
        type(c_ptr), value :: spl
      end function gsl_spline_init_c
    end interface

    gsl_spline_init = gsl_spline_init_c(spl%ptr, c_loc(x), c_loc(f), int(n, c_size_t))

  end function gsl_spline_init

  subroutine gsl_spline_alloc(spl, t, dim)
    !Returns a pointer to a newly allocated spline object
    integer, intent(in) :: t, dim
    type(gsl_spline_t), intent(out) :: spl
    interface
      type(c_ptr) function gsl_interp_type_new(type) bind(c)
        import
        integer(c_int), value :: type
      end function gsl_interp_type_new

      type(c_ptr) function gsl_spline_alloc_c(type, n) bind(c, name="gsl_spline_alloc")
        import
        type(c_ptr), value :: type
        integer(c_int), value :: n
      end function gsl_spline_alloc_c
    end interface

    spl%ptr = gsl_spline_alloc_c(gsl_interp_type_new(t), dim)

  end subroutine gsl_spline_alloc

  subroutine gsl_spline_free(spl)
    !Frees the interpolation object spl
    type(gsl_spline_t), intent(inout) :: spl
    interface
      subroutine gsl_spline_free_c(spl) bind(c, name="gsl_spline_free")
        import
        type(c_ptr), value :: spl
      end subroutine gsl_spline_free_c
    end interface

    call gsl_spline_free_c(spl%ptr)

  end subroutine gsl_spline_free

  subroutine gsl_interp_accel_alloc(acc)
    !Returns a pointer to an accelerator object, which
    !is a kind of iterator for interpolation lookups
    type(gsl_interp_accel_t), intent(inout) :: acc
    interface
      type(c_ptr) function gsl_interp_accel_alloc_c() bind(c, name="gsl_interp_accel_alloc")
        import
      end function gsl_interp_accel_alloc_c
    end interface

    acc%ptr = gsl_interp_accel_alloc_c()

  end subroutine gsl_interp_accel_alloc

  subroutine gsl_interp_accel_free(acc)
    !Frees the accelerator object acc
    type(gsl_interp_accel_t), intent(inout) :: acc
    interface
      subroutine gsl_interp_accel_free_c(acc) bind(c, name="gsl_interp_accel_free")
        import
        type(c_ptr), value :: acc
      end subroutine gsl_interp_accel_free_c
    end interface

    call gsl_interp_accel_free_c(acc%ptr)

  end subroutine gsl_interp_accel_free

  real(R8) function gsl_spline_eval(x, spl, acc)
    !Returns the interpolated value for a given point x
    real(R8), intent(in) :: x
    type(gsl_interp_accel_t), intent(inout) :: acc
    type(gsl_spline_t), intent(inout) :: spl
    interface
      real(c_double) function gsl_spline_eval_c(x, spl, acc) bind(c, name="gsl_spline_eval")
        import
        real(c_double), value :: x
        type(c_ptr), value :: spl, acc
      end function gsl_spline_eval_c
    end interface

    gsl_spline_eval =  gsl_spline_eval_c(x, spl%ptr, acc%ptr)

  end function gsl_spline_eval

  real(R8) function gsl_spline_eval_deriv(x, spl, acc)
    !Returns the derivative of an interpolated function for a given point x
    real(R8), intent(in) :: x
    type(gsl_interp_accel_t), intent(inout) :: acc
    type(gsl_spline_t), intent(inout) :: spl
    interface
      real(c_double) function gsl_spline_eval_deriv_c(x, spl, acc) bind(c, name="gsl_spline_eval_deriv")
        import
        real(c_double), value :: x
        type(c_ptr), value :: spl, acc
      end function gsl_spline_eval_deriv_c
    end interface

    gsl_spline_eval_deriv =  gsl_spline_eval_deriv_c(x, spl%ptr, acc%ptr)

  end function gsl_spline_eval_deriv

  real(R8) function gsl_spline_eval_deriv2(x, spl, acc)
    !Returns the second derivative d2 of an interpolated function for a given
    !point x
    real(R8), intent(in) :: x
    type(gsl_interp_accel_t), intent(inout) :: acc
    type(gsl_spline_t), intent(inout) :: spl
    interface
      real(c_double) function gsl_spline_eval_deriv2_c(x, spl, acc) bind(c, name="gsl_spline_eval_deriv2")
        import
        real(c_double), value :: x
        type(c_ptr), value :: spl, acc
      end function gsl_spline_eval_deriv2_c
    end interface

    gsl_spline_eval_deriv2 =  gsl_spline_eval_deriv2_c(x, spl%ptr, acc%ptr)

  end function gsl_spline_eval_deriv2

  real(R8) function gsl_spline_eval_integ(a, b, spl, acc)
    !Returns the numerical integral of an interpolated function over the range
    ![a, b]
    real(R8), intent(in) :: a, b
    type(gsl_interp_accel_t), intent(inout) :: acc
    type(gsl_spline_t), intent(inout) :: spl
    interface
      real(c_double) function gsl_spline_eval_integ_c(a, b, spl, acc) bind(c, name="gsl_spline_eval_integ")
        import
        real(c_double), value :: a, b
        type(c_ptr), value :: spl, acc
      end function gsl_spline_eval_integ_c
    end interface

    gsl_spline_eval_integ =  gsl_spline_eval_integ_c(a, b, spl%ptr, acc%ptr)

  end function gsl_spline_eval_integ

  ! Multidimensional Root-Finding

  subroutine gsl_multiroot_fsolver_alloc(s, t, n)
    !Returns a pointer to a newly allocated instance of a solver of type t for
    !a system of n dimensions
    type(gsl_multiroot_fsolver_t), intent(inout) :: s
    integer, intent(in) :: t, n
    interface
      type(c_ptr) function gsl_multiroot_fsolver_type_new(type) bind(c)
        !Auxiliary function to get a fsolver type from an integer
        import
        integer(c_int), value :: type
      end function gsl_multiroot_fsolver_type_new

      type(c_ptr) function gsl_multiroot_fsolver_alloc_c(type, dim) bind(c, name="gsl_multiroot_fsolver_alloc")
        import
        type(c_ptr), value :: type
        integer(c_int), value :: dim
      end function gsl_multiroot_fsolver_alloc_c
    end interface

    s%ptr = gsl_multiroot_fsolver_alloc_c(gsl_multiroot_fsolver_type_new(t), n)

  end subroutine gsl_multiroot_fsolver_alloc

  subroutine gsl_multiroot_fsolver_free(s)
    !Frees the accelerator object acc
    type(gsl_multiroot_fsolver_t), intent(inout) :: s
    interface
      subroutine gsl_multiroot_fsolver_free_c(s) bind(c, name="gsl_multiroot_fsolver_free")
        !Frees all the memory associated with the solver s
        import
        type(c_ptr), value :: s
      end subroutine gsl_multiroot_fsolver_free_c
    end interface

    call gsl_multiroot_fsolver_free_c(s%ptr)

  end subroutine gsl_multiroot_fsolver_free

end module gsl_m
