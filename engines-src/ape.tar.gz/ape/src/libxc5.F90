module libxc_interface_m
  use, intrinsic :: iso_c_binding
  use xc_f03_lib_m
  implicit none

  public

  interface
    ! This interface is currently missing from the Fortran Libxc 5 interface
    subroutine xc_f03_available_functional_numbers_by_name(list) bind(c, name="xc_available_functional_numbers_by_name")
      use iso_c_binding
      import
      integer(c_int), intent(out) :: list(*)
    end subroutine xc_f03_available_functional_numbers_by_name
  end interface

  integer(c_size_t), parameter :: LIBXC_SIZE_ONE = 1

end module libxc_interface_m
