!! Copyright (C) 2004-2013 M. Oliveira, F. Nogueira
!!
!! This program is free software; you can redistribute it and/or modify
!! it under the terms of the GNU General Public License as published by
!! the Free Software Foundation; either version 2, or (at your option)
!! any later version.
!!
!! This program is distributed in the hope that it will be useful,
!! but WITHOUT ANY WARRANTY; without even the implied warranty of
!! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
!! GNU General Public License for more details.
!!
!! You should have received a copy of the GNU General Public License
!! along with this program; if not, write to the Free Software
!! Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
!! 02110-1301, USA.
!!

#include "global.h"

module parser_symbols_m
  use global_m
  use oct_parser_m
  use mesh_m
  use mixing_m
  use quantum_numbers_m
  use eigensolver_m
  use libxc_interface_m
  use functionals_m
  use xc_m
  use ode_integrator_m
  use wave_equations_m
  use states_m
  use states_batch_m
  use ps_io_m
  use atom_m
  use numerical_tests_m
  use run_ape_m
  implicit none



                   !---Public/Private Statements---!

  private
  public :: set_parser_symbols

contains

  !-----------------------------------------------------------------------
  !> This subroutine defines some parser symbols. Basically they assign   
  !> parameters used in the code to possible values of input variables.   
  !-----------------------------------------------------------------------
  subroutine set_parser_symbols()

    integer :: ifunc, max_name_len
    character(len=:), allocatable :: known_func_names(:)
    integer, allocatable :: known_func_ids(:)

    ! CalculationMode
    call oct_parse_f90_putsym("ae",      AE)
    call oct_parse_f90_putsym("pp",      PP_GEN)
    call oct_parse_f90_putsym("pp_test", PP_TEST)
    call oct_parse_f90_putsym("nt",      NUM_TESTS)
    call oct_parse_f90_putsym("xc",      XC_EVAL)
    call oct_parse_f90_putsym("ip",      IP_CALC)

    ! EigensolverMode
    call oct_parse_f90_putsym("safe", EIGEN_SAFE)
    call oct_parse_f90_putsym("fast", EIGEN_FAST)

    ! PPScheme
    call oct_parse_f90_putsym("ham",   HAM)
    call oct_parse_f90_putsym("tm",    TM)
    call oct_parse_f90_putsym("rtm",   RTM)
    call oct_parse_f90_putsym("mrpp",  MRPP)
    call oct_parse_f90_putsym("rmrpp", RMRPP)
    call oct_parse_f90_putsym("mtm",   MTM)

    ! TheoryLevel
    call oct_parse_f90_putsym("independent_particles", INDEPENDENT_PARTICLES)
    call oct_parse_f90_putsym("dft",                   DFT)
    call oct_parse_f90_putsym("hartree_fock",          HARTREE_FOCK)
    call oct_parse_f90_putsym("hybrid",                HYBRID)

    ! WaveEquation
    call oct_parse_f90_putsym("schrodinger", SCHRODINGER)
    call oct_parse_f90_putsym("dirac",       DIRAC)
    call oct_parse_f90_putsym("scalar_rel",  SCALAR_REL)

    ! SpinMode
    call oct_parse_f90_putsym("unpolarized", 1)
    call oct_parse_f90_putsym("polarized",   2)

    ! MixingScheme
    call oct_parse_f90_putsym("linear",  MIX_LINEAR)
    call oct_parse_f90_putsym("broyden", MIX_BROYDEN)

    !MeshType
    call oct_parse_f90_putsym("linear", MESH_LINEAR)
    call oct_parse_f90_putsym("log1",   MESH_LOG1)
    call oct_parse_f90_putsym("log2",   MESH_LOG2)

    !MeshDerivMethod
    call oct_parse_f90_putsym("cubic_spline", MESH_CUBIC_SPLINE)
    call oct_parse_f90_putsym("finite_diff",  MESH_FINITE_DIFF)

    !SmearingFunction
    call oct_parse_f90_putsym("fixed_occ",       OCC_FIXED)
    call oct_parse_f90_putsym("semiconducting",  OCC_SEMICONDUCTING)
    call oct_parse_f90_putsym("averill_painter", OCC_AVERILL_PAINTER)

    ! XCFunctionals flags
    call oct_parse_f90_putsym("xc_deriv_method",   XC_DERIV_METHOD)
    call oct_parse_f90_putsym("xc_parameters",     XC_PARAMETERS)
    call oct_parse_f90_putsym("xc_dens_threshold", XC_DENS_THRESHOLD)

    ! XCFunctionals xc_deriv_method flag options
    call oct_parse_f90_putsym("xc_numerical", XC_DERIV_NUMERICAL)
    call oct_parse_f90_putsym("xc_analytical", XC_DERIV_ANALYTICAL)

    ! XC
    call oct_parse_f90_putsym("none", 0)

    ! LDAs
    call oct_parse_f90_putsym("lda_x",     XC_LDA_X)
    call oct_parse_f90_putsym("lda_x_rel", XC_LDA_X_REL)

    ! The functional IDs
    max_name_len = xc_f03_maximum_name_length()
    allocate(character(max_name_len) :: known_func_names(xc_f03_number_of_functionals()))
    allocate(known_func_ids(xc_f03_number_of_functionals()))

    call xc_f03_available_functional_numbers_by_name(known_func_ids)
    call xc_f03_available_functional_names(known_func_names)

    do ifunc = 1, xc_f03_number_of_functionals()
      call oct_parse_f90_putsym(trim(known_func_names(ifunc)), known_func_ids(ifunc))
    end do

    deallocate(known_func_names)
    deallocate(known_func_ids)

    ! This kinetic energy MGGA is not in Libxc
    call oct_parse_f90_putsym("mgga_k_ge2", XC_MGGA_K_GE2)

    ! XC corrections
    call oct_parse_f90_putsym("adsic", XC_CORRECTION_ADSIC)
    call oct_parse_f90_putsym("rhoxc", XC_CORRECTION_RHOXC)

    ! PPOutputFileFormat
    call oct_parse_f90_putsym("siesta",    PSIO_SIESTA   )
    call oct_parse_f90_putsym("fhi",       PSIO_FHI      )
    call oct_parse_f90_putsym("abinit5",   PSIO_ABINIT5  )
    call oct_parse_f90_putsym("abinit6",   PSIO_ABINIT6  )
    call oct_parse_f90_putsym("upf",       PSIO_UPF      )
    call oct_parse_f90_putsym("parsec",    PSIO_PARSEC   )
    call oct_parse_f90_putsym("latepp_so", PSIO_LATEPP_SO)

    ! ODESteppingFunction
    call oct_parse_f90_putsym("rk2",   ODE_RK2  )
    call oct_parse_f90_putsym("rk4",   ODE_RK4  )
    call oct_parse_f90_putsym("rkf4",  ODE_RKF4 )
    call oct_parse_f90_putsym("rkck4", ODE_RKCK4)
    call oct_parse_f90_putsym("rkpd8", ODE_RKPD8)

    ! PPTests
    call oct_parse_f90_putsym("ld",      TEST_LD)
    call oct_parse_f90_putsym("dm",      TEST_DM)
    call oct_parse_f90_putsym("ip_test", TEST_IP)
    call oct_parse_f90_putsym("ee",      TEST_EE)


    ! Numerical tests
    call oct_parse_f90_putsym("derivatives", TEST_DERIVATIVES)
    call oct_parse_f90_putsym("integration", TEST_INTEGRATION)
    call oct_parse_f90_putsym("hartree",     TEST_HARTREE)

    ! Test functions
    call oct_parse_f90_putsym("gaussian",    GAUSSIAN)
    call oct_parse_f90_putsym("inverse",     INVERSE)
    call oct_parse_f90_putsym("exponential", EXPONENTIAL)

  end subroutine set_parser_symbols

end module parser_symbols_m
