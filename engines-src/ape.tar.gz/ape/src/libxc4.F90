module libxc_interface_m
  use, intrinsic :: iso_c_binding
  use xc_f03_lib_m
  implicit none

  public

  integer(c_int), parameter :: LIBXC_SIZE_ONE = 1


contains

  ! Mock Libxc routines from newer versions
  integer function xc_f03_number_of_functionals()

    xc_f03_number_of_functionals2 = 247

  end function xc_f03_number_of_functionals

  subroutine xc_f03_available_functional_numbers_by_name(known_func_ids)
    integer :: known_func_ids(247)

    known_func_ids = [ &
      XC_LDA_C_WIGNER, &
      XC_LDA_C_RPA, &
      XC_LDA_C_HL, &
      XC_LDA_C_GL, &
      XC_LDA_C_XALPHA, &
      XC_LDA_C_VWN, &
      XC_LDA_C_PZ, &
      XC_LDA_C_PZ_MOD, &
      XC_LDA_C_OB_PZ, &
      XC_LDA_C_PW, &
      XC_LDA_C_PW_MOD, &
      XC_LDA_C_OB_PW, &
      XC_LDA_C_vBH, &
      XC_LDA_C_ML1, &
      XC_LDA_C_ML2, &
      XC_LDA_C_VWN_RPA, &
      XC_LDA_C_GOMBAS, &
      XC_LDA_C_PW_RPA, &
      XC_LDA_C_RC04, &
      XC_LDA_C_VWN_1, &
      XC_LDA_C_VWN_2, &
      XC_LDA_C_VWN_3, &
      XC_LDA_C_VWN_4, &
      XC_LDA_C_CHACHIYO, &
      XC_LDA_XC_TETER93, &
      XC_LDA_XC_ZLP, &
      XC_LDA_K_TF, &
      XC_LDA_K_LP, &
      XC_GGA_X_PBE, &
      XC_GGA_X_PBE_R, &
      XC_GGA_X_B86, &
      XC_GGA_X_B86_MGC, &
      XC_GGA_X_B88, &
      XC_GGA_X_G96, &
      XC_GGA_X_PW86, &
      XC_GGA_X_PW91, &
      XC_GGA_X_OPTX, &
      XC_GGA_X_DK87_R1, &
      XC_GGA_X_DK87_R2, &
      XC_GGA_X_LG93, &
      XC_GGA_X_FT97_A, &
      XC_GGA_X_FT97_B, &
      XC_GGA_X_PBE_SOL, &
      XC_GGA_X_RPBE , &
      XC_GGA_X_WC, &
      XC_GGA_X_mPW91, &
      XC_GGA_X_AM05, &
      XC_GGA_X_PBEA, &
      XC_GGA_X_MPBE, &
      XC_GGA_X_XPBE, &
      XC_GGA_X_BAYESIAN, &
      XC_GGA_X_PBE_JSJR, &
      XC_GGA_X_OPTB88_VDW, &
      XC_GGA_X_PBEK1_VDW, &
      XC_GGA_X_OPTPBE_VDW, &
      XC_GGA_X_RGE2, &
      XC_GGA_X_LB, &
      XC_GGA_X_RPW86, &
      XC_GGA_X_KT1, &
      XC_GGA_X_HERMAN, &
      XC_GGA_X_APBE, &
      XC_GGA_X_MB88, &
      XC_GGA_X_OL2, &
      XC_GGA_X_LBM, &
      XC_GGA_X_AIRY, &
      XC_GGA_X_LAG, &
      XC_GGA_X_HTBS, &
      XC_GGA_X_SOGGA, &
      XC_GGA_X_SOGGA11, &
      XC_GGA_X_C09X, &
      XC_GGA_X_SSB_SW, &
      XC_GGA_X_SSB, &
      XC_GGA_X_SSB_D, &
      XC_GGA_X_BPCCAC, &
      XC_GGA_X_WPBEH, &
      XC_GGA_X_HJS_PBE, &
      XC_GGA_X_HJS_PBE_SOL, &
      XC_GGA_X_HJS_B88, &
      XC_GGA_X_HJS_B97X, &
      XC_GGA_X_ITYH, &
      XC_GGA_X_LV_RPW86, &
      XC_GGA_X_N12, &
      XC_GGA_X_VMT_GE, &
      XC_GGA_X_VMT_PBE, &
      XC_GGA_X_VMT84_PBE, &
      XC_GGA_X_VMT84_GE, &
      XC_GGA_X_PBEINT, &
      XC_GGA_X_PBE_TCA, &
      XC_GGA_X_SFAT, &
      XC_GGA_X_AK13, &
      XC_GGA_X_LAMBDA_LO_N, &
      XC_GGA_X_LAMBDA_CH_N, &
      XC_GGA_X_LAMBDA_OC2_N, &
      XC_GGA_X_EV93, &
      XC_GGA_X_GAM, &
      XC_GGA_X_PBEFE, &
      XC_GGA_X_EB88, &
      XC_GGA_X_BEEFVDW, &
      XC_GGA_X_BCGP, &
      XC_GGA_C_PBE, &
      XC_GGA_C_LYP, &
      XC_GGA_C_P86, &
      XC_GGA_C_PBE_SOL, &
      XC_GGA_C_PW91, &
      XC_GGA_C_AM05, &
      XC_GGA_C_XPBE, &
      XC_GGA_C_LM, &
      XC_GGA_C_PBE_JRGX, &
      XC_GGA_C_RGE2, &
      XC_GGA_C_WL, &
      XC_GGA_C_WI, &
      XC_GGA_C_APBE, &
      XC_GGA_C_SOGGA11, &
      XC_GGA_C_SOGGA11_X, &
      XC_GGA_C_WI0, &
      XC_GGA_C_OP_XALPHA, &
      XC_GGA_C_OP_G96, &
      XC_GGA_C_OP_PBE, &
      XC_GGA_C_OP_B88, &
      XC_GGA_C_FT97, &
      XC_GGA_C_SPBE, &
      XC_GGA_C_REVTCA, &
      XC_GGA_C_TCA, &
      XC_GGA_C_OPTC, &
      XC_GGA_C_VPBE, &
      XC_GGA_C_PBEINT, &
      XC_GGA_C_ZPBESOL, &
      XC_GGA_C_ZPBEINT, &
      XC_GGA_C_HCTH_A, &
      XC_GGA_C_GAM, &
      XC_GGA_C_PBEFE, &
      XC_GGA_C_OP_PW91, &
      XC_GGA_C_PBE_MOL, &
      XC_GGA_C_BMK, &
      XC_GGA_C_TAU_HCTH, &
      XC_GGA_C_HYB_TAU_HCTH, &
      XC_GGA_C_BCGP, &
      XC_GGA_XC_HCTH_93 , &
      XC_GGA_XC_HCTH_120, &
      XC_GGA_XC_HCTH_147, &
      XC_GGA_XC_HCTH_407, &
      XC_GGA_XC_EDF1, &
      XC_GGA_XC_XLYP, &
      XC_GGA_XC_PBE1W, &
      XC_GGA_XC_MPWLYP1W, &
      XC_GGA_XC_PBELYP1W, &
      XC_GGA_XC_KT2, &
      XC_GGA_XC_TH1, &
      XC_GGA_XC_TH2, &
      XC_GGA_XC_TH3, &
      XC_GGA_XC_TH4, &
      XC_GGA_XC_MOHLYP, &
      XC_GGA_XC_MOHLYP2, &
      XC_GGA_XC_TH_FL, &
      XC_GGA_XC_TH_FC, &
      XC_GGA_XC_TH_FCFO, &
      XC_GGA_XC_TH_FCO, &
      XC_GGA_XC_HCTH_407P, &
      XC_GGA_XC_HCTH_P76, &
      XC_GGA_XC_HCTH_P14, &
      XC_GGA_XC_B97_GGA1, &
      XC_GGA_XC_OBLYP_D, &
      XC_GGA_XC_OPWLYP_D, &
      XC_GGA_XC_OPBE_D, &
      XC_GGA_XC_BEEFVDW, &
      XC_GGA_K_VW, &
      XC_GGA_K_GE2, &
      XC_GGA_K_GOLDEN, &
      XC_GGA_K_YT65, &
      XC_GGA_K_BALTIN, &
      XC_GGA_K_LIEB, &
      XC_GGA_K_ABSR1, &
      XC_GGA_K_ABSR2, &
      XC_GGA_K_GR, &
      XC_GGA_K_LUDENA, &
      XC_GGA_K_GP85, &
      XC_GGA_K_PEARSON, &
      XC_GGA_K_LLP, &
      XC_GGA_K_OL1, &
      XC_GGA_K_OL2, &
      XC_GGA_K_FR_B88, &
      XC_GGA_K_FR_PW86, &
      XC_GGA_K_DK, &
      XC_GGA_K_PERDEW, &
      XC_GGA_K_VSK, &
      XC_GGA_K_VJKS, &
      XC_GGA_K_ERNZERHOF, &
      XC_GGA_K_LC94, &
      XC_GGA_K_THAKKAR, &
      XC_GGA_K_APBE, &
      XC_GGA_K_TW1, &
      XC_GGA_K_TW2, &
      XC_GGA_K_TW3, &
      XC_GGA_K_TW4, &
      XC_GGA_K_MEYER, &
      XC_GGA_K_ABSP3, &
      XC_GGA_K_ABSP4, &
      XC_MGGA_X_LTA, &
      XC_MGGA_X_TPSS, &
      XC_MGGA_X_M06_L, &
      XC_MGGA_X_GVT4, &
      XC_MGGA_X_TAU_HCTH, &
      XC_MGGA_X_BR89, &
      XC_MGGA_X_BJ06, &
      XC_MGGA_X_TB09, &
      XC_MGGA_X_RPP09, &
      XC_MGGA_X_REVTPSS, &
      XC_MGGA_X_PKZB, &
      XC_MGGA_X_MS0, &
      XC_MGGA_X_MS1, &
      XC_MGGA_X_MS2, &
      XC_MGGA_X_MN12_L, &
      XC_MGGA_X_MK00, &
      XC_MGGA_X_MK00B, &
      XC_MGGA_X_BLOC, &
      XC_MGGA_X_MODTPSS, &
      XC_MGGA_X_MBEEF, &
      XC_MGGA_X_MBEEFVDW, &
      XC_MGGA_X_MVS, &
      XC_MGGA_X_SCAN, &
      XC_MGGA_X_B00, &
      XC_MGGA_C_TPSS, &
      XC_MGGA_C_VSXC, &
      XC_MGGA_C_M06_L, &
      XC_MGGA_C_M06_HF, &
      XC_MGGA_C_M06, &
      XC_MGGA_C_M06_2X, &
      XC_MGGA_C_M05, &
      XC_MGGA_C_M05_2X, &
      XC_MGGA_C_PKZB, &
      XC_MGGA_C_BC95, &
      XC_MGGA_C_M08_HX, &
      XC_MGGA_C_M08_SO, &
      XC_MGGA_C_M11, &
      XC_MGGA_C_M11_L, &
      XC_MGGA_C_MN12_L, &
      XC_MGGA_C_MN12_SX, &
      XC_MGGA_C_REVTPSS, &
      XC_MGGA_C_TPSSLOC, &
      XC_MGGA_C_DLDF, &
      XC_MGGA_C_MN15_L, &
      XC_MGGA_C_SCAN, &
      XC_MGGA_XC_OTPSS_D, &
      XC_MGGA_XC_TPSSLYP1W, &
      XC_MGGA_XC_ZLP, &
      XC_MGGA_XC_B97M_V, &
      XC_MGGA_XC_CC06 &
    ]

  end subroutine xc_f03_available_functional_numbers_by_name


  subroutine xc_f03_available_functional_names(known_func_names)
    character(len=15), intent(out) :: known_func_names(247)

    known_func_names = [ &
      "lda_c_wigner      ", &
      "lda_c_rpa         ", &
      "lda_c_hl          ", &
      "lda_c_gl          ", &
      "lda_c_xalpha      ", &
      "lda_c_vwn         ", &
      "lda_c_pz          ", &
      "lda_c_pz_mod      ", &
      "lda_c_ob_pz       ", &
      "lda_c_pw          ", &
      "lda_c_pw_mod      ", &
      "lda_c_ob_pw       ", &
      "lda_c_vbh         ", &
      "lda_c_ml1         ", &
      "lda_c_ml2         ", &
      "lda_c_vwn_rpa     ", &
      "lda_c_gombas      ", &
      "lda_c_pw_rpa      ", &
      "lda_c_rc04        ", &
      "lda_c_vwn_1       ", &
      "lda_c_vwn_2       ", &
      "lda_c_vwn_3       ", &
      "lda_c_vwn_4       ", &
      "lda_c_chachiyo    ", &
      "lda_xc_teter93    ", &
      "lda_xc_zlp        ", &
      "lda_k_tf          ", &
      "lda_k_lp          ", &
      "gga_x_pbe         ", &
      "gga_x_pbe_r       ", &
      "gga_x_b86         ", &
      "gga_x_b86_mgc     ", &
      "gga_x_b88         ", &
      "gga_x_g96         ", &
      "gga_x_pw86        ", &
      "gga_x_pw91        ", &
      "gga_x_optx        ", &
      "gga_x_dk87_r1     ", &
      "gga_x_dk87_r2     ", &
      "gga_x_lg93        ", &
      "gga_x_ft97_a      ", &
      "gga_x_ft97_b      ", &
      "gga_x_pbe_sol     ", &
      "gga_x_rpbe        ", &
      "gga_x_wc          ", &
      "gga_x_mpw91       ", &
      "gga_x_am05        ", &
      "gga_x_pbea        ", &
      "gga_x_mpbe        ", &
      "gga_x_xpbe        ", &
      "gga_x_bayesian    ", &
      "gga_x_pbe_jsjr    ", &
      "gga_x_optb88_vdw  ", &
      "gga_x_pbek1_vdw   ", &
      "gga_x_optpbe_vdw  ", &
      "gga_x_rge2        ", &
      "gga_x_lb          ", &
      "gga_x_rpw86       ", &
      "gga_x_kt1         ", &
      "gga_x_herman      ", &
      "gga_x_apbe        ", &
      "gga_x_mb88        ", &
      "gga_x_ol2         ", &
      "gga_x_lbm         ", &
      "gga_x_airy        ", &
      "gga_x_lag         ", &
      "gga_x_htbs        ", &
      "gga_x_sogga       ", &
      "gga_x_sogga11     ", &
      "gga_x_c09x        ", &
      "gga_x_ssb_sw      ", &
      "gga_x_ssb         ", &
      "gga_x_ssb_d       ", &
      "gga_x_bpccac      ", &
      "gga_x_wpbeh       ", &
      "gga_x_hjs_pbe     ", &
      "gga_x_hjs_pbe_sol ", &
      "gga_x_hjs_b88     ", &
      "gga_x_hjs_b97x    ", &
      "gga_x_ityh        ", &
      "gga_x_lv_rpw86    ", &
      "gga_x_n12         ", &
      "gga_x_vmt_ge      ", &
      "gga_x_vmt_pbe     ", &
      "gga_x_vmt84_pbe   ", &
      "gga_x_vmt84_ge    ", &
      "gga_x_pbeint      ", &
      "gga_x_tca         ", &
      "gga_x_sfat        ", &
      "gga_x_ak13        ", &
      "gga_x_lambda_lo_n ", &
      "gga_x_lambda_ch_n ", &
      "gga_x_lambda_oc2_n", &
      "gga_x_ev93        ", &
      "gga_x_gam         ", &
      "gga_x_pbefe       ", &
      "gga_x_eb88        ", &
      "gga_x_beefvdw     ", &
      "gga_x_bcgp        ", &
      "gga_c_pbe         ", &
      "gga_c_lyp         ", &
      "gga_c_p86         ", &
      "gga_c_pbe_sol     ", &
      "gga_c_pw91        ", &
      "gga_c_am05        ", &
      "gga_c_xpbe        ", &
      "gga_c_lm          ", &
      "gga_c_pbe_jrgx    ", &
      "gga_c_rge2        ", &
      "gga_c_wl          ", &
      "gga_c_wi          ", &
      "gga_c_apbe        ", &
      "gga_c_sogga11     ", &
      "gga_c_sogga11_x   ", &
      "gga_c_wi0         ", &
      "gga_c_op_xalpha   ", &
      "gga_c_op_g96      ", &
      "gga_c_op_pbe      ", &
      "gga_c_op_b88      ", &
      "gga_c_ft97        ", &
      "gga_c_spbe        ", &
      "gga_c_revtca      ", &
      "gga_c_tca         ", &
      "gga_c_optc        ", &
      "gga_c_vpbe        ", &
      "gga_c_pbeint      ", &
      "gga_c_zpbesol     ", &
      "gga_c_zpbeint     ", &
      "gga_c_hcth_a      ", &
      "gga_c_gam         ", &
      "gga_c_pbefe       ", &
      "gga_c_op_pw91     ", &
      "gga_c_pbe_mol     ", &
      "gga_c_bmk         ", &
      "gga_c_tau_hcth    ", &
      "gga_c_hyb_tau_hcth", &
      "gga_c_bcgp        ", &
      "gga_xc_hcth_93    ", &
      "gga_xc_hcth_120   ", &
      "gga_xc_hcth_147   ", &
      "gga_xc_hcth_407   ", &
      "gga_xc_edf1       ", &
      "gga_xc_xlyp       ", &
      "gga_xc_pbe1w      ", &
      "gga_xc_mpwlyp1w   ", &
      "gga_xc_pbelyp1w   ", &
      "gga_xc_kt2        ", &
      "gga_xc_th1        ", &
      "gga_xc_th2        ", &
      "gga_xc_th3        ", &
      "gga_xc_th4        ", &
      "gga_xc_mohlyp     ", &
      "gga_xc_mohlyp2    ", &
      "gga_xc_th_fl      ", &
      "gga_xc_th_fc      ", &
      "gga_xc_th_fcfo    ", &
      "gga_xc_th_fco     ", &
      "gga_xc_hcth_407p  ", &
      "gga_xc_hcth_p76   ", &
      "gga_xc_hcth_p14   ", &
      "gga_xc_b97_gga1   ", &
      "gga_xc_oblyp_d    ", &
      "gga_xc_opwlyp_d   ", &
      "gga_xc_opbe_d     ", &
      "gga_xc_beefvdw    ", &
      "gga_k_vw          ", &
      "gga_k_ge2         ", &
      "gga_k_golden      ", &
      "gga_k_yt65        ", &
      "gga_k_baltin      ", &
      "gga_k_lieb        ", &
      "gga_k_absr1       ", &
      "gga_k_absr2       ", &
      "gga_k_gr          ", &
      "gga_k_ludena      ", &
      "gga_k_gp85        ", &
      "gga_k_pearson     ", &
      "gga_k_llp         ", &
      "gga_k_ol1         ", &
      "gga_k_ol2         ", &
      "gga_k_fr_b88      ", &
      "gga_k_fr_pw86     ", &
      "gga_k_dk          ", &
      "gga_k_perdew      ", &
      "gga_k_vsk         ", &
      "gga_k_vjks        ", &
      "gga_k_ernzerhof   ", &
      "gga_k_lc94        ", &
      "gga_k_thakkar     ", &
      "gga_k_apbe        ", &
      "gga_k_tw1         ", &
      "gga_k_tw2         ", &
      "gga_k_tw3         ", &
      "gga_k_tw4         ", &
      "gga_k_meyer       ", &
      "gga_k_absp3       ", &
      "gga_k_absp4       ", &
      "mgga_x_lta        ", &
      "mgga_x_tpss       ", &
      "mgga_x_m06_l      ", &
      "mgga_x_gvt4       ", &
      "mgga_x_tau_hcth   ", &
      "mgga_x_br89       ", &
      "mgga_x_bj06       ", &
      "mgga_x_tb09       ", &
      "mgga_x_rpp09      ", &
      "mgga_x_revtpss    ", &
      "mgga_x_pkzb       ", &
      "mgga_x_ms0        ", &
      "mgga_x_ms1        ", &
      "mgga_x_ms2        ", &
      "mgga_x_mn12_l     ", &
      "mgga_x_mk00       ", &
      "mgga_x_mk00b      ", &
      "mgga_x_bloc       ", &
      "mgga_x_modtpss    ", &
      "mgga_x_mbeef      ", &
      "mgga_x_mbeffvdw   ", &
      "mgga_x_mvs        ", &
      "mgga_x_scan       ", &
      "mgga_x_b00        ", &
      "mgga_c_tpss       ", &
      "mgga_c_vsxc       ", &
      "mgga_c_m06_l      ", &
      "mgga_c_m06_hf     ", &
      "mgga_c_m06        ", &
      "mgga_c_m06_2x     ", &
      "mgga_c_m05        ", &
      "mgga_c_m05_2x     ", &
      "mgga_c_pkzb       ", &
      "mgga_c_bc95       ", &
      "mgga_c_m08_hx     ", &
      "mgga_c_m08_so     ", &
      "mgga_c_m11        ", &
      "mgga_c_m11_l      ", &
      "mgga_c_mn12_l     ", &
      "mgga_c_mn12_sx    ", &
      "mgga_c_revtpss    ", &
      "mgga_c_tpssloc    ", &
      "mgga_c_dldf       ", &
      "mgga_c_mn15_l     ", &
      "mgga_c_scan       ", &
      "mgga_xc_otpss_d   ", &
      "mgga_xc_tpsslyp1w ", &
      "mgga_xc_zlp       ", &
      "mgga_xc_b97m_v    ", &
      "mgga_xc_cc06      " &
      ]


  end subroutine xc_f03_available_functional_names


end module libxc_interface_m
