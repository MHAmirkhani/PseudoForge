/*
 Copyright (C) 2026 M. Oliveira

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 02110-1301, USA.

*/

#include <gsl/gsl_odeiv.h>
#include <gsl/gsl_spline.h>
#include <gsl/gsl_multiroots.h>


const gsl_odeiv_step_type *gsl_odeiv_step_type_new(int type) {
  /* Auxiliary function to get a step type from an integer */
  const gsl_odeiv_step_type *step_type;

  switch (type) {
  case 1: // Embedded 2nd order Runge-Kutta with 3rd order error estimate
    step_type = gsl_odeiv_step_rk2;
    break;
  case 2: // 4th order (classical) Runge-Kutta
    step_type = gsl_odeiv_step_rk4;
    break;
  case 3: // Embedded 4th order Runge-Kutta-Fehlberg method with 5th order error estimate. This method is a good general-purpose integrator
    step_type = gsl_odeiv_step_rkf45;
    break;
  case 4: // Embedded 4th order Runge-Kutta Cash-Karp method with 5th order error estimate
    step_type = gsl_odeiv_step_rkck;
    break;
  case 5: // Embedded 8th order Runge-Kutta Prince-Dormand method with 9th order error estimate
    step_type = gsl_odeiv_step_rk8pd;
    break;
  case 6: // Implicit 2nd order Runge-Kutta at Gaussian points
    step_type = gsl_odeiv_step_rk2imp;
    break;
  case 7:
    step_type = gsl_odeiv_step_rk2simp;
    break;
   case 8: // Implicit 4th order Runge-Kutta at Gaussian points
    step_type = gsl_odeiv_step_rk4imp;
    break;
  case 9: // Implicit Bulirsch-Stoer method of Bader and Deuflhard. This algorithm requires the Jacobian
    step_type = gsl_odeiv_step_bsimp;
    break;
  case 10: // M=1 implicit Gear method
    step_type = gsl_odeiv_step_gear1;
    break;
  case 11: // M=2 implicit Gear method
    step_type = gsl_odeiv_step_gear2;
    break;
  default:
    step_type = NULL;
    break;
  }
  return step_type;
}


const gsl_interp_type *gsl_interp_type_new(int type) {
  /* Auxiliary function to get an interp type from an integer */
  const gsl_interp_type *interp_type;

  switch(type) {
  case 1 : // linear interpolation
    interp_type = gsl_interp_linear;
    break;
  case 2 : // polynomial interpolation
    interp_type = gsl_interp_polynomial;
    break;
  case 3 : // cubic spline with natural boundary conditions
    interp_type = gsl_interp_cspline;
    break;
  case 4 : // cubic spline with periodic boundary conditions
    interp_type = gsl_interp_cspline_periodic;
    break;
  case 5 : // Akima spline with natural boundary conditions
    interp_type = gsl_interp_akima;
    break;
  case 6 : // Akima spline with periodic boundary conditions
    interp_type = gsl_interp_akima_periodic;
    break;
  default:
    interp_type = NULL;
  }
  return interp_type;
}


const gsl_multiroot_fsolver_type *gsl_multiroot_fsolver_type_new(int type) {
  /* Auxiliary function to get a multiroot fsolver type from an integer */
  const gsl_multiroot_fsolver_type *fsolver_type;

  switch(type) {
  case 1 : // hybrid algorithm with internal scaling.
    fsolver_type = gsl_multiroot_fsolver_hybrids;
    break;
  case 2 : // hybrid algorithm without internal scaling.
    fsolver_type = gsl_multiroot_fsolver_hybrid;
    break;
  case 3 : // discrete Newton algorithm
    fsolver_type = gsl_multiroot_fsolver_dnewton;
    break;
  case 4 : // Broyden algorithm
    fsolver_type = gsl_multiroot_fsolver_broyden;
    break;
  default:
    fsolver_type = NULL;
  }
  return fsolver_type;
}
