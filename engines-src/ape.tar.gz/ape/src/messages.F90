!! Copyright (C) 2004-2012 M. Oliveira, F. Nogueira
!!
!! This program is free software; you can redistribute it and/or modify
!! it under the terms of the GNU General Public License as published by
!! the Free Software Foundation; either version 2, or (at your option)
!! any later version.
!!
!! This program is distributed in the hope that it will be useful,
!! but WITHOUT ANY WARRANTY; without even the implied warranty of
!! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
!! GNU General Public License for more details.
!!
!! You should have received a copy of the GNU General Public License
!! along with this program; if not, write to the Free Software
!! Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
!! 02110-1301, USA.
!!

#include "global.h"

module messages_m
  use global_m
  use oct_parser_m
  use utilities_m
  implicit none


                    !---Global Variables---!

  !Default unit numbers
  integer :: stderr = 0
  integer :: stdin  = 5
  integer :: stdout = 6

  character(len=120)  :: message(200) !< Array were the messages are stored

  integer :: verbose = 0 !< The verbosity level

  !Verbosity levels of warning and normal messages
  integer, parameter :: WARNING = 0,  &
                        NORMAL  = 10, &
                        DEBUG   = 1000


                    !---Public/Private Statements---!

  private
  public :: messages_init, &
            message, &
            write_fatal, &
            write_warning, &
            write_info, &
            print_date, &
            assert_die, &
            stderr, &
            stdin, &
            stdout

contains

  !-----------------------------------------------------------------------
  !> Initializes the messages: gets the init time, the vervose level and  
  !> checks if the code is in debug mode or not.                          
  !-----------------------------------------------------------------------
  subroutine messages_init()

    !Read verbose
    verbose = oct_parse_f90_int('Verbose', 0)

    !Are we in debug mode?
    if (verbose >= DEBUG) then
      in_debug_mode = .true.
    else
      in_debug_mode = .false.
    end if

  end subroutine messages_init

  !-----------------------------------------------------------------------
  !> Writes a message and stops the programm.                             
  !-----------------------------------------------------------------------
  subroutine write_fatal(no_lines)
    integer, intent(in) :: no_lines !< number of lines to write

    integer :: i

    write(stderr,'(//"Fatal Error (description follows)")')
    do i = 1, no_lines
      write(stderr,'(2X, A)') trim(message(i))
    end do
    write(stderr,*)
    stop

  end subroutine write_fatal

  !-----------------------------------------------------------------------
  !> If the verbosity level is greater than the WARNING level it writes a 
  !> warning message.                                                     
  !-----------------------------------------------------------------------
  subroutine write_warning(no_lines)
    integer, intent(in) :: no_lines !< number of lines to write

    integer :: i

    if (verbose > WARNING) then
      do i = 1, no_lines
        write(stdout, '(A)') "Warning: "//trim(message(i))
      end do
    end if

  end subroutine write_warning

  !-----------------------------------------------------------------------
  !> If the verbosity level is greater than the NORMAL level it writes a  
  !> message.                                                             
  !-----------------------------------------------------------------------
  subroutine write_info(no_lines, verbose_limit, unit)
    integer,           intent(in) :: no_lines      !< number of lines to write
    integer, optional, intent(in) :: verbose_limit !< if present, only writes the message if the verbosity level is greater than the verbose_limit
    integer, optional, intent(in) :: unit          !< if present, writes the message to unit, instead of stdout, without taking into account the verbosity.

    integer :: i

    if (present(unit)) then
      do i = 1, no_lines
        write(unit, '(A)') trim(message(i))
      end do
    else
      if (verbose > NORMAL) then
        do i = 1, no_lines
          if (.not.present(verbose_limit)) then
            write(stdout, '(A)') trim(message(i))
          else if (verbose > verbose_limit) then
            write(stdout, '(A)') trim(message(i))
          end if
        end do
      end if
    end if

  end subroutine write_info

  !-----------------------------------------------------------------------
  !> Write a message about a failed assertion and stops the program.      
  !-----------------------------------------------------------------------
  subroutine assert_die(s, f, l)
    character(len=*), intent(in) :: s !< failed assertion
    character(len=*), intent(in) :: f !< name of the file where the assertion failed
    integer,          intent(in) :: l !< number of the line where the assertion failed

    write(message(1), '(2a)') 'Assertion "', trim(s)
    write(message(2), '(a,i5)') 'failed in line ', l
    write(message(3), '(3a)') 'in file "', f, '"'
    call write_fatal(3)

  end subroutine assert_die

  !-----------------------------------------------------------------------
  !> Prints a string followed by the date and time. The format is the     
  !> following: " 'str' YYYY/MM/DD at HH:MM "                             
  !-----------------------------------------------------------------------
  subroutine print_date(str)
    character(len = *), intent(in) :: str !< string to be written

    integer :: val(8)

    call date_and_time(values=val)
    message(1) = ""
    write(message(3),'(a,i4,a1,i2.2,a1,i2.2,a,i2.2,a1,i2.2,a1,i2.2)') &
      str , val(1), "/", val(2), "/", val(3), &
      " at ", val(5), ":", val(6), ":", val(7)
    message(2) = str_center(trim(message(3)), 70)
    message(3) = ""
    call write_info(3)

  end subroutine print_date

end module messages_m
