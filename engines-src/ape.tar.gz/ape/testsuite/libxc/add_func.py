#!/usr/bin/env python3
"""Add a Libxc functional to the APE regression test suite.

Usage::

    add_func.py <ape_executable> <func_id> <func_family> <func_type> <func_name>

Arguments
---------
ape_executable
    Path to the APE binary.
func_id
    Numeric Libxc functional ID (e.g. ``1``).
func_family
    Functional family prefix used in the APE symbol (e.g. ``lda``, ``gga``).
func_type
    Functional type: ``x`` (exchange), ``c`` (correlation), ``xc`` (combined),
    or ``k`` (kinetic-energy density).
func_name
    Functional name suffix.  Pass a single space (``" "``) when the functional
    symbol should contain only family and type (no trailing name component).

The script performs the following steps for each of the five reference systems
(01-H, 02-H_spin, 03-He, 04-He_spin, 05-Li):

1. Creates ``<func_id>-<func_symbol>.inp`` (skipped if it already exists) and
   stages it with ``git add``.
2. Runs APE twice inside a temporary directory: first for the reference system
   (all-electron calculation) and then for the functional under test.
3. Extracts energies and potential values from the APE output files.
4. Appends a new entry to the corresponding ``<system>.yaml`` regression test
   file with the extracted reference values and automatically computed
   tolerances.
"""
import re
import sys
import subprocess
import tempfile
from pathlib import Path

from pseudotest.value_extractors import get_target_line, find_pattern_line, extract_field_from_line


def insert_entry(yaml_path, new_block, fid):
    """Insert *new_block* into the Inputs section of *yaml_path* in ascending functional-ID order."""
    text = open(yaml_path).read()
    m = re.search(r'^Inputs:\n', text, re.MULTILINE)
    header = text[:m.end()]
    body   = text[m.end():]

    blocks = re.split(r'(?=^  \S)', body, flags=re.MULTILINE)
    blocks = [b for b in blocks if b.strip()]

    setup = []
    funcs = []
    for block in blocks:
        key = re.match(r'  (\S+):', block).group(1)
        m3 = re.match(r'^(\d{3})-', key)
        if m3:
            funcs.append((int(m3.group(1)), block))
        else:
            setup.append(block)

    funcs.append((fid, new_block))
    funcs.sort(key=lambda x: x[0])
    result = header + ''.join(setup) + ''.join(b for _, b in funcs)
    open(yaml_path, 'w').write(result)

def usage():
    print(f"Usage: {sys.argv[0]} executable func_id func_family func_type func_name")
    sys.exit(1)

if len(sys.argv) != 6:
    usage()

ape          = sys.argv[1]
func_id      = sys.argv[2]
func_family  = sys.argv[3]
func_type    = sys.argv[4]
func_name    = sys.argv[5]

if func_name == " ":
    func_symbol = f"{func_family}_{func_type}"
else:
    func_symbol = f"{func_family}_{func_type}_{func_name}"

inp_file = f"{func_id}-{func_symbol}.inp"

# Skip if already done
if Path(inp_file).exists():
    print(f"Skipping {func_id}-{func_symbol} (already exists)")
    sys.exit(0)

with open(inp_file, "w") as f:
    if func_type == "k":
        f.write(f"\nCalculationMode = xc\nVerbose = 40\n\nKEDFunctional = {func_symbol}\nXCFunctional = none\n")
    else:
        f.write(f"\nCalculationMode = xc\nVerbose = 40\n\nXCFunctional = {func_symbol}\n")

subprocess.run(["git", "add", inp_file])


def compute_tol(val):
    """Return a tolerance string suitable for the YAML test file.

    The tolerance is set to 1e-5 times the absolute value of *val*, so that a
    future run is allowed to differ by that relative amount.  A floor of
    ``2.00e-08`` is applied for very small or missing values.
    """
    if not val:
        return "2.00e-08"
    v = abs(float(val))
    if v > 1e-7:
        return f"{v * 1e-5:.2e}"
    else:
        return "2.00e-08"


def read_field(path, line_1based, field=2):
    """Return a whitespace-delimited field from a specific line of a file.

    Parameters
    ----------
    path:
        Path to the file.
    line_1based:
        Line number (1-based).
    field:
        Field index (1-based, whitespace-delimited).

    Returns an empty string when the file does not exist or the line/field is
    out of range.
    """
    try:
        lines = Path(path).read_text().splitlines()
        line = get_target_line(lines, line_1based - 1)
        return extract_field_from_line(line, field) or ""
    except FileNotFoundError:
        return ""


def grep_field(path, pattern, field=4, offset=0):
    """Search a file for a pattern and extract a field from the matched line.

    Parameters
    ----------
    path:
        Path to the file.
    pattern:
        Substring to search for (first match is used).
    field:
        Field index (1-based, whitespace-delimited) to extract from the target
        line.
    offset:
        Line offset from the matched line: ``0`` returns the matching line
        itself, ``1`` returns the next line, etc.

    Returns an empty string when the file does not exist or the pattern is not
    found.
    """
    try:
        lines = Path(path).read_text().splitlines()
        line = find_pattern_line(lines, pattern, offset)
        return extract_field_from_line(line, field) or ""
    except FileNotFoundError:
        return ""


def run_ape(system, tmp):
    """Run APE for the reference system and then for the functional under test.

    Both runs are executed inside *tmp* (the temporary working directory).
    Output is suppressed.
    """
    with open(f"{system}.inp") as stdin_f:
        subprocess.run([ape], stdin=stdin_f, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=tmp)
    with open(inp_file) as stdin_f:
        subprocess.run([ape], stdin=stdin_f, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=tmp)


# For combined xc functionals APE writes potential to v_x (not v_xc)
pot_type = "x" if func_type == "xc" else func_type


def update_yaml(system):
    """Insert a non-spin-polarised XC/exchange/correlation entry into *system*.yaml in order."""
    with tempfile.TemporaryDirectory() as _tmp:
        tmp = Path(_tmp)
        run_ape(system, tmp)

        energy = grep_field(tmp / "xc/info", "energy", 4)
        pot1   = read_field(tmp / f"xc/v_{pot_type}", 8)
        pot2   = read_field(tmp / f"xc/v_{pot_type}", 162)
        pot3   = read_field(tmp / f"xc/v_{pot_type}", 207)

        tol1 = compute_tol(pot1)
        tol2 = compute_tol(pot2)
        tol3 = compute_tol(pot3)

        entry = (
            f"\n  {inp_file}:\n"
            f"    Matches:\n"
            f"      \"E{func_type}\":\n"
            f"        file: xc/info\n"
            f"        grep: \"Exchange-correlation energy\"\n"
            f"        column: 35\n"
            f"        value: {energy}\n"
            f"        tol: 0.0\n"
            f"      \"v{pot_type}(r)\":\n"
            f"        file: xc/v_{pot_type}\n"
            f"        line: [8, 162, 207]\n"
            f"        column: 20\n"
            f"        match: [\"r1\", \"ri\", \"rmax\"]\n"
            f"        value: [{pot1}, {pot2}, {pot3}]\n"
            f"        tol: [{tol1}, {tol2}, {tol3}]\n"
        )
        insert_entry(f"{system}.yaml", entry, int(func_id))


def update_yaml_spin(system):
    """Insert a spin-polarised XC/exchange/correlation entry into *system*.yaml in order."""
    with tempfile.TemporaryDirectory() as _tmp:
        tmp = Path(_tmp)
        run_ape(system, tmp)

        energy = grep_field(tmp / "xc/info", "energy", 4)
        p1_up  = read_field(tmp / f"xc/v_{pot_type}_up", 8)
        p2_up  = read_field(tmp / f"xc/v_{pot_type}_up", 162)
        p3_up  = read_field(tmp / f"xc/v_{pot_type}_up", 207)
        p1_dn  = read_field(tmp / f"xc/v_{pot_type}_dn", 8)
        p2_dn  = read_field(tmp / f"xc/v_{pot_type}_dn", 162)
        p3_dn  = read_field(tmp / f"xc/v_{pot_type}_dn", 207)

        t1_up, t2_up, t3_up = compute_tol(p1_up), compute_tol(p2_up), compute_tol(p3_up)
        t1_dn, t2_dn, t3_dn = compute_tol(p1_dn), compute_tol(p2_dn), compute_tol(p3_dn)

        entry = (
            f"\n  {inp_file}:\n"
            f"    Matches:\n"
            f"      \"E{func_type}\":\n"
            f"        file: xc/info\n"
            f"        grep: \"Exchange-correlation energy\"\n"
            f"        column: 35\n"
            f"        value: {energy}\n"
            f"        tol: 0.0\n"
            f"      \"v{pot_type}_up(r)\":\n"
            f"        file: xc/v_{pot_type}_up\n"
            f"        line: [8, 162, 207]\n"
            f"        column: 20\n"
            f"        match: [\"r1\", \"ri\", \"rmax\"]\n"
            f"        value: [{p1_up}, {p2_up}, {p3_up}]\n"
            f"        tol: [{t1_up}, {t2_up}, {t3_up}]\n"
            f"      \"v{pot_type}_dn(r)\":\n"
            f"        file: xc/v_{pot_type}_dn\n"
            f"        line: [8, 162, 207]\n"
            f"        column: 20\n"
            f"        match: [\"r1\", \"ri\", \"rmax\"]\n"
            f"        value: [{p1_dn}, {p2_dn}, {p3_dn}]\n"
            f"        tol: [{t1_dn}, {t2_dn}, {t3_dn}]\n"
        )
        insert_entry(f"{system}.yaml", entry, int(func_id))


def update_k_yaml(system):
    """Insert a non-spin-polarised kinetic-energy density entry into *system*.yaml in order."""
    with tempfile.TemporaryDirectory() as _tmp:
        tmp = Path(_tmp)
        run_ape(system, tmp)

        energy = grep_field(tmp / "xc/info", "Kinetic Energy", 2, offset=1)
        pot1   = read_field(tmp / "xc/app_tau", 9)
        pot2   = read_field(tmp / "xc/app_tau", 163)
        pot3   = read_field(tmp / "xc/app_tau", 208)

        tol1 = compute_tol(pot1)
        tol2 = compute_tol(pot2)
        tol3 = compute_tol(pot3)

        entry = (
            f"\n  {inp_file}:\n"
            f"    Matches:\n"
            f"      \"Ek\":\n"
            f"        file: xc/info\n"
            f"        grep: \"Kinetic Energy\"\n"
            f"        line: 1\n"
            f"        column: 35\n"
            f"        value: {energy}\n"
            f"        tol: 0.0\n"
            f"      \"tau(r)\":\n"
            f"        file: xc/app_tau\n"
            f"        line: [9, 163, 208]\n"
            f"        column: 20\n"
            f"        match: [\"r1\", \"ri\", \"rmax\"]\n"
            f"        value: [{pot1}, {pot2}, {pot3}]\n"
            f"        tol: [{tol1}, {tol2}, {tol3}]\n"
        )
        insert_entry(f"{system}.yaml", entry, int(func_id))


def update_k_yaml_spin(system):
    """Insert a spin-polarised kinetic-energy density entry into *system*.yaml in order."""
    with tempfile.TemporaryDirectory() as _tmp:
        tmp = Path(_tmp)
        run_ape(system, tmp)

        energy = grep_field(tmp / "xc/info", "Kinetic Energy", 2, offset=1)
        p1_up  = read_field(tmp / "xc/app_tau_up", 9)
        p2_up  = read_field(tmp / "xc/app_tau_up", 163)
        p3_up  = read_field(tmp / "xc/app_tau_up", 208)
        p1_dn  = read_field(tmp / "xc/app_tau_dn", 9)
        p2_dn  = read_field(tmp / "xc/app_tau_dn", 163)
        p3_dn  = read_field(tmp / "xc/app_tau_dn", 208)

        t1_up, t2_up, t3_up = compute_tol(p1_up), compute_tol(p2_up), compute_tol(p3_up)
        t1_dn, t2_dn, t3_dn = compute_tol(p1_dn), compute_tol(p2_dn), compute_tol(p3_dn)

        entry = (
            f"\n  {inp_file}:\n"
            f"    Matches:\n"
            f"      \"Ek\":\n"
            f"        file: xc/info\n"
            f"        grep: \"Kinetic Energy\"\n"
            f"        line: 1\n"
            f"        column: 35\n"
            f"        value: {energy}\n"
            f"        tol: 0.0\n"
            f"      \"tau_up(r)\":\n"
            f"        file: xc/app_tau_up\n"
            f"        line: [9, 163, 208]\n"
            f"        column: 20\n"
            f"        match: [\"r1\", \"ri\", \"rmax\"]\n"
            f"        value: [{p1_up}, {p2_up}, {p3_up}]\n"
            f"        tol: [{t1_up}, {t2_up}, {t3_up}]\n"
            f"      \"tau_dn(r)\":\n"
            f"        file: xc/app_tau_dn\n"
            f"        line: [9, 163, 208]\n"
            f"        column: 20\n"
            f"        match: [\"r1\", \"ri\", \"rmax\"]\n"
            f"        value: [{p1_dn}, {p2_dn}, {p3_dn}]\n"
            f"        tol: [{t1_dn}, {t2_dn}, {t3_dn}]\n"
        )
        insert_entry(f"{system}.yaml", entry, int(func_id))


if func_type == "k":
    update_k_yaml("01-H")
    update_k_yaml_spin("02-H_spin")
    update_k_yaml("03-He")
    update_k_yaml_spin("04-He_spin")
    update_k_yaml_spin("05-Li")
else:
    update_yaml("01-H")
    update_yaml_spin("02-H_spin")
    update_yaml("03-He")
    update_yaml_spin("04-He_spin")
    update_yaml_spin("05-Li")
