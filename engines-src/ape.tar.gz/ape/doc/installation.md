# Installation

## Prerequisites

APE is written in standard Fortran 2003, with some routines written in C. To
build it you will need both a C compiler (`gcc` works just fine) and a Fortran
2003 compiler (`gfortran` also works fine).

Besides the compiler, you will also need:

1. **CMake**: APE uses the [CMake](https://cmake.org/) build system.

2. **make** or **ninja**: CMake can use different build back-ends, which are the
   programs that perform the actual build. **make** is the default, but
   [Ninja](https://ninja-build.org/) is an alternative to **make** that focuses
   on speed and we highly recommend using it instead.

3. **GSL**: The [GNU Scientific Library](https://www.gnu.org/software/gsl/) is
   heavily used in APE. You will need version 1.0 or higher.

4. **Libxc**: [Libxc](https://libxc.gitlab.io/) is a library of exchange and
   correlation functionals. Any version equal or greater than 4.0.0 should work.

5. **pseudotest**: The [pseudotest](https://github.com/micaeljtoliveira/pseudotest/)
   Python package is required to run the regression testsuite. Install it with
   pip:

   ```sh
   pip install pseudotest
   ```

   or into an isolated virtual environment next to the source directory:

   ```sh
   python -m venv <srcdir>/../venv
   <srcdir>/../venv/bin/pip install pseudotest
   ```

   CMake searches for the `pseudotest` executable in `PATH` and, as a
   fallback, in `<srcdir>/../venv/bin`.


## Obtaining the sources

The first step is to obtain the source code. The code is freely available and
can be obtained by downloading the appropriate file from the Releases page on
[Gitlab](https://gitlab.com/ape/ape/-/releases), or by cloning the git
repository.

If you downloaded one of the compressed files, you now need to uncompress
it. For example, if you downloaded the `tar.gz` file:

```sh
tar xzf ape-<version>.tar.gz
```

In the following, `<srcdir>` denotes the directory containing the sources of
APE.

The `<srcdir>` should contains the following subdirectories:

- `doc`: The documentation of APE in *Markdown* format.

- `liboct_parser`: The parser used by APE. This is the parser from
  `Octopus`.

- `sample`: Sample input files for APE.

- `src`: Fortran 2003 source files. Note that these have to be preprocessed
  before being fed to the Fortran compiler, so do not be scared by the \#
  directives.

- `testsuite`: APE regression testsuite.

## Compiling the code

Next you will need to configure and compile the code. APE uses CMake, so
building the code usually requires a configure step:

```sh
cmake -B <builddir> -S <srcdir>
```

and a build step:

```sh
cmake --build <builddir>
```

where `<builddir>` is a user-supplied path where CMake will build the code. This
can be, for example, `./build`, but avoid using a directory inside
`<srcdir>`. Note that CMake will automatically create the build directory if it
does not exist already.

To speed-up the build, it is possible to tell CMake to use parallelism by
passing the `-j` flags:

```sh
cmake --build <builddir> -j <nprocs>
```

where `<nprocs>` is the number of processes to use. When omitting `<nprocs>`,
CMake will set it to be equal the number of CPU cores in your system.


## Configuration options

CMake provides several options to customize the build. This is usually done by
setting some flags or environment variable during the configure step.

Note that many of the options discussed bellow are cached between subsequent
calls to CMake. To remove these cached variables and start from "fresh" one can
use the `--fresh` flag:

```sh
cmake -B <builddir> -S <srcdir> --fresh
```


### Build backend

The default backend is `make`, but this can be changed by using the `-G`
flag. For example, the following

```sh
cmake -B <builddir> -S <srcdir> -G Ninja
```

will select Ninja as build backend.


### Build type

CMake build types provide a high-level way to different sets of compiler and
linker behavior. By default, CMake provides the following build types:

- Debug
- Release
- RelWithDebInfo
- MinSizeRel

and APE provides the following custom type:

- Coverage

The build type can be specified using the CMAKE_BUILD_TYPE variable:

```sh
cmake -B <builddir> -S <srcdir> -DCMAKE_BUILD_TYPE=Debug
```

If no build type is specified, APE will be configured using the `Release`
type, as this is the type that should be used for most use-cases.

Note that providing a non-existing build type is allowed. This will result in
CMake using a so-called empty build and no build-specific compiler or linker
flags will be used. Although this is usually not what the user intended, it can
be useful, as it provides a way of fully customizing the compiler flags used
(see next section).

### Compilers and compiler flags

CMake will try to automatically detect the compilers to use, but one can specify
them by passing the appropriate CMake flags at configure time:

```sh
cmake -B <builddir> -S <srcdir> -DCMAKE_Fortran_COMPILER=<fortran_compiler> -DCMAKE_C_COMPILER=<c_compiler>
```

One can also customize the compiler flags used and there are several ways of
doing this.

The simplest option is to select a different build type (see previous section),
but this is limited to the existing types and their corresponding flags.

For a more fine-grained control of the flags, one can use the
`-DCMAKE_<language>_FLAGS` option:

```sh
cmake -B <builddir> -S <srcdir> -DCMAKE_Fortran_FLAGS=<fortran_flags> -DCMAKE_C_FLAGS=<c_flags>
```

Note that these flags will be **prepended** to the flags defined by the build
type. Similarly, one can set the `FFLAGS` and CFLAGS environment variables.

```sh
export FFLAGS=<fortran_flags>
export CFLAGS=<c_flags>
cmake -B <builddir> -S <srcdir>
```

Note that if both `FFLAGS`/`CFLAGS` and
`-DCMAKE_Fortran_FLAGS`/`-DCMAKE_C_FLAGS` are used, the later take precedence
and the former are ignored.

The linker and linker flags can also be customized. Please refer to the CMake
documentation for the corresponding options.


### Dependencies

During the configure step, CMake will try to find the location of the required
GSL and Libxc external dependencies Libxc. If unable to find any of them, CMake
will exit with an error. This will typically happen if the libraries are
installed in a non-standard location. If that's the case, one can tell CMake
where to find the libraries using the `<package>_ROOT` variables:

```sh
cmake -B <builddir> -S <srcdir> -DLibxc_ROOT=/path/to/libxc -DGSL_ROOT=/path/to/GSL
```

In both cases, `/path/to/...` should be the library's installation prefix
without the final `lib/`


## Testing

Once the compilation is finished, make sure that `pseudotest` is installed (see
[Prerequisites](#prerequisites)), then launch the testsuite:

```sh
ctest --test-dir <build_dir> --output-on-failure -L all
```

## Installation

If all tests were passed, you can then install the code with
```sh
cmake --install <build_dir> --prefix=<installation_prefix>
```

The executable will be installed in `<installation_prefix>/bin`. On Linux, the
`<installation_prefix>` defaults to `/usr/local`.

If everything went fine, you should now be able to run APE.


## Troubleshooting

So, something went wrong. Here is a list of things that might have gone wrong.

**Some tests of the testsuite fail**: When running the testsuite, one or more
tests fail.

- Is the test failing because of a very small numerical difference?  While
  running a test, if a test case is failed, the code will print some extra
  information about the failure, namely the calculated value, the reference
  value, and the allowed tolerance. This should look like this:

          Match Failed
           Calculated value : -24.344302
           Reference value  : -24.344198
           Difference       : 0.000104
           Tolerance        : 8e-5

  If the difference is slightly larger than the tolerance, like in the previous
  example, and if the same happens for all the failed test cases, then it is
  likely that there is nothing wrong with your compilation.

**Could NOT find GSL**: We assume that you have already installed GSL
but, for some reason, you were not able to compile the code.

- Is the library installed in a standard location? If not, did you pass the
  correct `-DGSL_ROOT` flag at configure time?

**Could not find the Libxc library**: We assume that you have already installed
libxc but, for some reason, you were not able to compile the code.

- Is the library installed in a standard location? If not, did you pass the
  correct `-DLibxc_ROOT` flag at configure time?

- Did you use the same Fortran compiler when compiling Libxc? Unfortunately the
  compilation of Fortran modules generates compiler dependent files (usually
  with the `.mod` extension). Since APE uses the Fortran interface of Libxc, it
  is required that you use the same Fortran compiler for APE and Libxc.

**Error while loading shared libraries**: You have already compiled the
code, but it fails to run, giving an error message about a failure in
locating some shared object file.

- Did you set the `LD_LIBRARY_PATH` environment variable? If some of the
  libraries used to compile APE are installed in a non-standard directory (like
  `/opt/libxc`), you will have to add the path to the directory where the
  library objects are installed to the `LD_LIBRARY_PATH` environment
  variable. If you are using bash, this is done with the following command:

```sh
export LD_LIBRARY_PATH=/path/to/libxc/lib:$LD_LIBRARY_PATH
```

**Fatal Error**: Sometimes the code stops after issuing a *Fatal Error*
message. Here is a list of some of the most common errors and a brief
explanation of their origin and some possible solutions.

- *Unable to bracket eigenvalue for state xxx.* This error occurs when the
  eigensolver is unable to find the eigenvalue for a given orbital. Most of the
  times this will happen when an occupied orbital becomes unbound.

- *Generation of pseudopotentials from spin-polarized calculations is not
  implemented!* You are trying to generate a pseudopotential from a
  spin-polarized calculation, but this is not possible in APE.  Although there
  are schemes to generate spin-dependent pseudopotentials, for most
  applications, spin-polarized calculations can be performed using
  pseudopotentials generated for a spin-unpolarized atom. This is because
  spin-polarization should come from the valence electrons. Furthermore,
  spin-dependent pseudopotentials cannot be used in the same way as
  spin-independent ones and most DFT codes don’t know how to handle them.

**Whatever went wrong...**: If something else went wrong, please create an issue
on [Gitlab](https://gitlab.com/ape/ape/).


---
