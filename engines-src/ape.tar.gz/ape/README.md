Atomic Pseudopotential Engine

[![Latest Release](https://gitlab.com/ape/ape/-/badges/release.svg)](https://gitlab.com/ape/ape/-/releases)
[![Pipeline Status](https://gitlab.com/ape/ape/badges/master/pipeline.svg)](https://gitlab.com/ape/ape/-/commits/master)


# About

The Atomic Pseudopotential Engine (APE) is a computer package designed to
generate and test norm-conserving pseudopotentials within Density Functional
Theory.

# Key Features

The generated pseudopotentials can be either non-relativistic, scalar
relativistic or fully relativistic and can explicitly include semi-core
states. A wide range of exchange-correlation functionals is included through
[Libxc](https://libxc.gitlab.io/).

APE can output the pseudopotentials in a variety of file formats suitable to use
in many of the most popular DFT codes. These include (in no particular order):

- [Siesta](https://siesta-project.org/siesta)
- [Octopus](https://octopus-code.org/)
- [ABINIT](http://www.abinit.org/)
- [Quantum-Espresso](https://www.quantum-espresso.org/)


# Documentation

A detailed manual and some examples can be found
[here](https://ape.gitlab.io/ape/).


# Installation

APE uses CMake as a build system. CMake-based packages are installed by
configuring the project, and then building and installing it. Typically this
looks something like:

```sh
cmake -B  <build_dir> -S  <src_dir>
cmake --build  <build_dir>
cmake --install  <build_dir> --prefix=<installation_prefix>
```

Detailed instructions can be found
[here](https://ape.gitlab.io/ape/installation/).


# Contributing

Contributions are welcome! Please open an issue or submit a merge request if
you’d like to add features, fix bugs, or improve documentation.

For significant contributions, we recommend discussing proposed changes in an
issue before opening a merge request.


# How to cite APE

In case you find the code useful, we kindly suggest that you cite the following
article that describes APE in more detail:

Micael J.T. Oliveira, Fernando Nogueira, _"Generating relativistic
pseudo-potentials with explicit incorporation of semi-core states using APE, the
Atomic Pseudo-potentials Engine"_, [Computer Physics
Communications](https://doi.org/10.1016/j.cpc.2007.11.003) **178**, 524 (2008)


# License

This project is distributed under the GPLv2.
